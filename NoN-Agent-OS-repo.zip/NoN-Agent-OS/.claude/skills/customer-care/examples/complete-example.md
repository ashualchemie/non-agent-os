# Illustrative worked packet: Customer Care Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All case details are illustrative.

The customer asks where order EX-492 is and requests a refund. Commerce evidence shows the order is paid and shipped. Carrier evidence has not updated for 72 hours. The published delivery window expired yesterday. Policy POL-SHIP-04 permits an investigation now and a refund or replacement only after the lost-shipment threshold or carrier confirmation. The current agent has no refund authority above INR 1,000. Order value is INR 2,499.

## Resolution

- Permitted now: Open a carrier investigation, mark the case high priority, and set a 24-hour update.
- Requires approval: Refund or replacement if the lost threshold is met, because the value exceeds agent authority.
- Close evidence: Carrier resolution plus verified refund, replacement, or delivery and customer communication.

## Response draft

I am sorry this has gone beyond the delivery window. I checked order EX-492 and confirmed that it left the warehouse, but the carrier has not posted a new scan for 72 hours. I have opened a priority trace today. We will update you within 24 hours, even if the carrier has not completed its review. If the shipment is confirmed lost or reaches the policy threshold, a supervisor will approve the eligible refund or replacement option. You do not need to contact the carrier yourself.

Status: `external_action_pending` for sending the message and opening the trace. No refund is promised or processed.

