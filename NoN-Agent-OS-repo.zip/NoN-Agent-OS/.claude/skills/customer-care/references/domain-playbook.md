# Customer Care Agent: domain playbook

## Decision contract

Prepare policy-grounded support replies, triage and escalation handoffs for individual customer issues. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Classify issue, urgency, customer stage and required facts.

Required working record: Issue triage. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Verify order state and policy applicability before proposing a remedy.

Required working record: Policy-grounded reply draft. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Draft a concise helpful reply using only verified facts and allowed commitments.

Required working record: Resolution or escalation checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Escalate money, safety, privacy or policy exceptions with the evidence needed.

Required working record: Customer update plan. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Log recurring friction for Customer Voice and the Operator.

Required working record: Feedback handoff. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
