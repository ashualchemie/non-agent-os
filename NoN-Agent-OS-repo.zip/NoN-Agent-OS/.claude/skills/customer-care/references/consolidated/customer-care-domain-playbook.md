# Customer Care Domain Playbook

## 1. Policy knowledge base

Each policy record needs policy ID, type, market, channel, product scope, current rule, customer wording, exceptions, authority, source, owner, version, effective date, review date, and approval state. Keep returns, refunds, exchanges, cancellation, delivery, warranty, privacy, subscription, promotions, and payment policies separate but cross-check conflicts.

Use STORE-041 to STORE-050 and CRO-089 to CRO-099. The public policy and internal resolution rule must not contradict each other.

## 2. Ticket taxonomy

Tag primary reason, secondary reason, journey stage, product or SKU, order state, delivery state, payment state, severity, sentiment only when useful, resolution, policy exception, root-cause owner, and reopen state. Suggested reason families:

- Product information and fit
- Order change or cancellation
- Payment failure, duplicate, or chargeback
- Shipping, delay, NDR, loss, or damage
- Return, exchange, refund, or warranty
- Subscription, consent, or marketing preference
- Safety, quality, counterfeit, or compliance
- Account, privacy, fraud, or identity
- Promotion, price, gift, or loyalty
- Marketplace or wholesale order

## 3. Evidence and authority

Before resolving, identify the system of record for order, payment, fulfilment, carrier, inventory, policy, and customer communication. Record conflicts. Authority must state maximum refund, replacement, credit, shipping upgrade, exception, and account-change limits by role.

## 4. Response construction

Use five parts:

1. Acknowledge the actual issue without exaggerated empathy.
2. State verified facts and avoid blaming the customer or partner.
3. State the action that can be taken now.
4. Give the owner and realistic deadline.
5. Explain the contingency and next contact route.

Do not bury conditions, quote internal risk labels, or promise a carrier, bank, refund, or restock date not supported by evidence.

## 5. Decision trees

A tree must name inputs, policy version, identity requirement, order states, authority, branches, escalation, terminal outcomes, close evidence, and test cases. For example, a refund tree distinguishes cancelled before capture, captured but unfulfilled, shipped, delivered, returned, partially refunded, fully refunded, disputed, and fraud review.

## 6. Service recovery

Match remedy to verified harm and authority. Options include explanation, corrected information, expedited follow-up, replacement, refund, shipping correction, account repair, or limited approved credit. Do not use discounting to silence safety, privacy, discrimination, or systemic operational issues.

## 7. SLA and closure

Define first-response, next-update, decision, resolution, and reopen clocks from named business events. Pause clocks only under documented rules. A ticket closes when the promised action is verified, communication is complete, required records are stored, and next work is assigned.

## 8. VOC loop

Aggregate de-identified volume, rate, severity, repeat contacts, resolution time, reopen, refund exposure, and product or journey concentration. Separate ticket counts from customer counts and order counts. Route root causes to Product Page, Store Audit, Stock, Paid Media, Retention, Supplier, or Workflow owners with evidence.

