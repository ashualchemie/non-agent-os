# Customer Care Decision Rules

## P0 blockers

- Safety, legal, privacy, fraud, or identity risk requires specialist review.
- Policy version or jurisdiction is unknown.
- Order, payment, or delivery evidence conflicts materially.
- Required refund, replacement, cancellation, or account-change authority is absent.
- A response would expose unnecessary personal or payment data.

## Resolution hierarchy

1. Protect safety, privacy, identity, and funds.
2. Correct the operational state where authorized.
3. Give accurate explanation and next action.
4. Offer approved recovery only after the core resolution is addressed.
5. Capture root cause and prevent recurrence.

## Exception rule

An exception record requires case ID, current policy, requested exception, customer and business impact, maximum exposure, precedent risk, compensating control, approver, expiry or one-time scope, and closure evidence.

## Send rule

A draft may be `draft_ready`. Sending remains `external_action_pending` unless the user authorizes the named channel, recipient or case, and exact message. Refunds, replacements, cancellations, credits, and account changes need separate action authority even if the message is approved.

