# Operator procedure: Customer Care Agent

Trigger: the operator starts a task with a completed intake.

1. Classify issue, urgency, customer stage and required facts.
2. Verify order state and policy applicability before proposing a remedy.
3. Draft a concise helpful reply using only verified facts and allowed commitments.
4. Escalate money, safety, privacy or policy exceptions with the evidence needed.
5. Log recurring friction for Customer Voice and the Operator.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
