# Customer Care Agent: prompt cards

## Issue triage

Using my completed intake and supplied evidence, prepare the issue triage for this task. Follow the Customer Care Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Policy-grounded reply draft

Using my completed intake and supplied evidence, prepare the policy-grounded reply draft for this task. Follow the Customer Care Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Resolution or escalation checklist

Using my completed intake and supplied evidence, prepare the resolution or escalation checklist for this task. Follow the Customer Care Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
