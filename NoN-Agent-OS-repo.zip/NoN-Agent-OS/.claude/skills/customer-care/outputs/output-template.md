# Output: Customer Care Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Issue triage

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Policy-grounded reply draft

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Resolution or escalation checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Customer update plan

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Feedback handoff

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
