# Customer Voice & Objection Agent: prompt cards

## Evidence register

Using my completed intake and supplied evidence, prepare the evidence register for this task. Follow the Customer Voice & Objection Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Theme and objection matrix

Using my completed intake and supplied evidence, prepare the theme and objection matrix for this task. Follow the Customer Voice & Objection Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Customer phrase bank

Using my completed intake and supplied evidence, prepare the customer phrase bank for this task. Follow the Customer Voice & Objection Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
