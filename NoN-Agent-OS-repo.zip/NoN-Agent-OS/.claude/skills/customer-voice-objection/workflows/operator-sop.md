# Operator procedure: Customer Voice & Objection Agent

Trigger: the operator starts a task with a completed intake.

1. Define one research decision and separate received records from usable records.
2. Preserve original wording, remove duplicates, redact direct identifiers and record exclusions.
3. Code trigger, desired progress, objection, alternative, proof sought and purchase stage.
4. Build themes with supporting count, denominator, dated evidence IDs and counterevidence.
5. Rank messaging implications by decision relevance and evidence strength.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
