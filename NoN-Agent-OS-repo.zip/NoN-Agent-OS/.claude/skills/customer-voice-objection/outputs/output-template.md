# Output: Customer Voice & Objection Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Evidence register

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Theme and objection matrix

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Customer phrase bank

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Segment implications

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Messaging brief with limitations

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
