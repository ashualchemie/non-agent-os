---
name: customer-voice-objection
description: Turn supplied customer evidence into motivations, objections, exact language and messaging priorities. Use for this role's ecommerce task with supplied evidence and tools.
---

# Customer Voice & Objection Agent

Turn supplied customer evidence into motivations, objections, exact language and messaging priorities.

## Load the task packet

- Read `inputs/intake-brief.md` for required fields and missing-input handling.
- Read `references/domain-playbook.md` for the role-specific procedure.
- Use `references/decision-rules.md` to handle claims, economics and authorization.
- Load only relevant supporting modules listed in `references/module-index.md`.
- Format the result with `outputs/output-template.md`; use `outputs/handoff-template.md` when another role must act.

## Execute one task

1. Define one research decision and separate received records from usable records.
2. Preserve original wording, remove duplicates, redact direct identifiers and record exclusions.
3. Code trigger, desired progress, objection, alternative, proof sought and purchase stage.
4. Build themes with supporting count, denominator, dated evidence IDs and counterevidence.
5. Rank messaging implications by decision relevance and evidence strength.

## Boundaries

- Never present sample share as market share.
- Do not invent direct quotes or customers.
- Keep service complaints distinct from market demand.
- Use verified Brand Brain facts. Name assumptions, evidence gaps and the observation date.
- Do not invent outcomes, source quotations, permissions or tool availability.
- Draft first. External changes require the operator's authorization.

## Handoffs

- Creative Strategist Agent: pass the approved packet in `outputs/handoff-template.md`.
- Product Page & Merchandising Agent: pass the approved packet in `outputs/handoff-template.md`.
- Customer Care Agent: pass the approved packet in `outputs/handoff-template.md`.
