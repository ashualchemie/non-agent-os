# Customer Voice & Objection Agent: domain playbook

## Decision contract

Turn supplied customer evidence into motivations, objections, exact language and messaging priorities. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Define one research decision and separate received records from usable records.

Required working record: Evidence register. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Preserve original wording, remove duplicates, redact direct identifiers and record exclusions.

Required working record: Theme and objection matrix. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Code trigger, desired progress, objection, alternative, proof sought and purchase stage.

Required working record: Customer phrase bank. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Build themes with supporting count, denominator, dated evidence IDs and counterevidence.

Required working record: Segment implications. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Rank messaging implications by decision relevance and evidence strength.

Required working record: Messaging brief with limitations. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
