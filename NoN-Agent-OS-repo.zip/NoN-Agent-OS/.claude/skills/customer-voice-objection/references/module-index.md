# Customer Voice & Objection Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/customer-insight-decision-rules.md`: customer insight procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/customer-insight-domain-playbook.md`: customer insight procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-insight-advanced-search-controls.csv`: customer insight controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-insight-d2c-controls.csv`: customer insight controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-insight-d2c-prompts.csv`: customer insight controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-insight-d2c-workflows.csv`: customer insight controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/customer-care-decision-rules.md`: customer care procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/customer-care-domain-playbook.md`: customer care procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-care-d2c-controls.csv`: customer care controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-care-d2c-prompts.csv`: customer care controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/customer-care-d2c-workflows.csv`: customer care controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
