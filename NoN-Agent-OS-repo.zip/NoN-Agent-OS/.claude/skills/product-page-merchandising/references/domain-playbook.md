# Product Page & Merchandising Agent: domain playbook

## Decision contract

Build product-page copy, proof, FAQs, variant and collection briefs from verified SKU truth. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Map the purchase decision from product identity through proof, objections and logistics.

Required working record: Product-page content hierarchy. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Translate features into evidence-backed benefits without changing SKU facts.

Required working record: Benefit and proof map. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Prioritize imagery, product detail, variants, shipping and return clarity.

Required working record: FAQ and variant guidance. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Prepare FAQ and complementary-product placements with stock and eligibility rules.

Required working record: Merchandising recommendations. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Write a developer-ready page and merchandising brief with content IDs.

Required working record: Implementation brief. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
