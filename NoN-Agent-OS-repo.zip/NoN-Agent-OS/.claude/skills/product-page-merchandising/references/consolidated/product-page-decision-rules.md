# Product Page Decision Rules

## Claim acceptance

Use a claim only when the claim register provides exact wording or an approved boundary, evidence source, applicable product or variant, owner, and review status. If proof supports a narrower statement, narrow the copy.

## Above the fold

Prioritize product identity, outcome, price, proof, selection, and action. Do not spend the first viewport on brand manifesto, autoplay media, or unsupported superlatives.

## Variants

- Keep selected media, price, stock, identifier, delivery, and URL state synchronized.
- Prevent impossible combinations.
- Explain material differences before add to cart.
- Do not inherit a claim from one variant to all variants without evidence.

## Comparison

Compare on verifiable, decision-relevant facts using an explicit basis and date when needed. Include limitations. Do not invent competitor weaknesses or create a rigged table.

## FAQ

Include questions supported by search, support, review, interview, or sales evidence. Route policy answers to the current policy source. Do not create an FAQ only to repeat sales copy.

## Urgency and stock

Display only current system-derived inventory, capacity, price, or time limits. If the source is not reliable, omit the urgency device.

## Delivery

Prefer location-aware range with cutoff and serviceability. Do not state one promise when geography, inventory, or shipping method varies.

## Missing critical facts

Block publication if product identity, price basis, included quantity, essential safety or suitability information, delivery, returns, or a primary claim is unresolved.

## Structured data

Specify only properties supported by visible content and current data. Validation success does not prove eligibility or ranking.
