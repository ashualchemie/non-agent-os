# Product Page Domain Playbook

## Product truth model

Create a field-level register with:

- product and variant identity
- category and intended use
- contents, quantity, dimensions, materials, ingredients, compatibility, or fit
- mechanism and approved benefits
- usage, care, storage, warnings, and limitations
- price, tax basis, discount basis, subscription terms, and offer eligibility
- inventory, delivery, return, warranty, and support rules
- claims, substantiation, approval status, and expiry or review date
- review and endorsement permission
- image and media rights

Every output field must point to a truth record or remain unresolved.

## Information sequence

The first mobile viewport should establish:

1. exact product and selected variant
2. primary outcome in approved language
3. price and offer terms
4. high-value proof or decision fact
5. variant and quantity selection
6. clear next action

The rest of the page should answer, in evidence order:

- Is this for my situation?
- What is included?
- How does it work?
- What will I need to do?
- What proof can I inspect?
- How does it compare with my alternative?
- What are the limits or exclusions?
- When will it arrive?
- Can I return it?

## Copy layers

- Identity: exact product, variant, quantity, and category
- Outcome: approved result without exaggeration
- Mechanism: why the product can plausibly deliver the outcome
- Proof: evidence, demonstration, specifications, reviews, or process
- Fit: who and what it is for, plus important non-fit
- Action: next step and purchase-state information

Do not hide limitations in FAQs if they change purchase suitability.

## Media sequence

Each asset must answer a named question. Common jobs include product recognition, scale, included contents, use sequence, texture or detail, fit, comparison, proof, and care. Provide alt text based on information, not keyword stuffing.

## Reviews and questions

Represent real distribution, source, date, incentive, and permission. Surface decision-useful reviews and unanswered questions. Do not manufacture summaries that imply unsupported prevalence.

## Search and machine-readable facts

Write a unique intent-aligned title and useful preview. Keep visible facts, feed data, and Product or Offer markup aligned. Model variants consistently. Include shipping, returns, ratings, identifiers, and availability only when current and eligible.

## Handoff

For each component provide purpose, copy, data source, behavior, responsive rule, accessibility requirement, analytics event, owner, and acceptance test.
