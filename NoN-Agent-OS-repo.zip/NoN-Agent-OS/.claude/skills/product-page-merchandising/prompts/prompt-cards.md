# Product Page & Merchandising Agent: prompt cards

## Product-page content hierarchy

Using my completed intake and supplied evidence, prepare the product-page content hierarchy for this task. Follow the Product Page & Merchandising Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Benefit and proof map

Using my completed intake and supplied evidence, prepare the benefit and proof map for this task. Follow the Product Page & Merchandising Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## FAQ and variant guidance

Using my completed intake and supplied evidence, prepare the faq and variant guidance for this task. Follow the Product Page & Merchandising Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
