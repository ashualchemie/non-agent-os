# Illustrative worked packet: Product Page & Merchandising Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All entities and facts are illustrative.

## Product truth

Product: Field Flask 750  
Variant: 750 ml, Slate  
Included: bottle, cap, cleaning brush  
Price: INR 1,799, tax inclusive  
Material claim: food-contact stainless steel, approved only for the documented grade  
Temperature claim: removed because the supplied test did not match the final cap assembly  
Delivery: pincode-dependent range from the shipping service  
Returns: unused items within the stated policy window, subject to policy conditions

## Decision model

Situation: commuter wants one bottle that fits a standard bag pocket and is easy to clean.  
Questions: exact dimensions, leak behavior, cap parts, cleaning, weight, and delivery.  
Non-fit: users requiring a one-hand sports nozzle.

## Page sequence

1. Identity and selected variant
2. Approved outcome: carry water without a bulky wide body
3. Price, included contents, and pincode delivery lookup
4. Dimension diagram beside a common bag-pocket outline
5. Cap assembly and cleaning demonstration
6. Material specification and evidence source
7. Fit and non-fit
8. Review evidence
9. Delivery, returns, care, and support

## Sample above-fold copy

Field Flask 750  
A slim 750 ml bottle designed for everyday bags.  
INR 1,799, taxes included.  
Includes bottle, cap, and cleaning brush.  
Select color, enter pincode for delivery, then add to cart.

The draft did not say "leakproof" because the supplied evidence covered upright transport only.

## Claim-proof record

PP-C01: "750 ml capacity." Source PF-002, production specification, applies to all current variants, approved.  
PP-C02: "Fits most standard backpack bottle pockets." Source PF-011 covered only three bag models, so the claim was narrowed to a dimension diagram and exact measurements.  
PP-C03: temperature retention claim, blocked because test assembly differed from sale assembly.

## FAQ example

Question: Does the cap come apart for cleaning?  
Question source: CI-support-031, CI-review-022.  
Answer source: PF-007 assembly guide.  
Answer: Yes. The gasket and inner cap can be removed using the documented steps. The page links the illustrated care guide.

## Status

Ready with conditions. Publication is blocked until the final product identifiers and cap-assembly temperature test are resolved. All other components have mobile, accessibility, analytics, and structured-data acceptance tests.
