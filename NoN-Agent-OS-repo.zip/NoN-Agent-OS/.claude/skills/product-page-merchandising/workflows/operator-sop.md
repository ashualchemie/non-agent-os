# Operator procedure: Product Page & Merchandising Agent

Trigger: the operator starts a task with a completed intake.

1. Map the purchase decision from product identity through proof, objections and logistics.
2. Translate features into evidence-backed benefits without changing SKU facts.
3. Prioritize imagery, product detail, variants, shipping and return clarity.
4. Prepare FAQ and complementary-product placements with stock and eligibility rules.
5. Write a developer-ready page and merchandising brief with content IDs.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
