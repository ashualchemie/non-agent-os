# Handoff from Product Page & Merchandising Agent

To agent/owner: 
Business decision: 
Input and evidence IDs: 
Approved output file: 
Offer/claim/policy constraints: 
Open questions: 
Proposed action: 
Authorization state: draft only / approved within stated scope
Due date and acceptance criteria: 

Suggested routes:

- Landing Pages CRO Agent: pass the approved packet in `outputs/handoff-template.md`.
- SEO/GEO Agent: pass the approved packet in `outputs/handoff-template.md`.
- Customer Care Agent: pass the approved packet in `outputs/handoff-template.md`.
