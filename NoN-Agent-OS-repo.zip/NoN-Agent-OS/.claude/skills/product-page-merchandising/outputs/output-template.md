# Output: Product Page & Merchandising Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Product-page content hierarchy

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Benefit and proof map

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## FAQ and variant guidance

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Merchandising recommendations

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Implementation brief

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
