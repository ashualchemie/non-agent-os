# Output: Email, SMS & WhatsApp Recovery Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Segment and trigger matrix

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Email, SMS and WhatsApp drafts

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Offer ladder

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Purchase and consent suppression

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Recovery measurement plan

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
