# Email, SMS & WhatsApp Recovery Agent: recovery flows

WELCOME: entry requires a permitted new-contact event; no purchase assumption. BROWSE: product-view evidence plus identifiable permitted contact. CART: cart contents and current stock, suppress on paid purchase. SUBMITTED-UNPAID: reconcile provider/order state and suppress success, cancellation or previous equivalent message. Draft assistance early and later objection or offer stages within approved margins. Respect opt-outs, local send windows and channel permission. Store one dedupe key per journey/order/stage.
