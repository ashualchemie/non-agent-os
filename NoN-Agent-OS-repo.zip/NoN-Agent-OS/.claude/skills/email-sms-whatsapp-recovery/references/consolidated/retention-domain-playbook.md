# Retention Domain Playbook

## Foundation

### Consent and identity

Record source, purpose, channel, timestamp, notice version, jurisdiction, and revocation. Email, SMS, and WhatsApp are separate permissions. Define anonymous-to-known identity stitching and the source of truth for suppression.

### Event contract

For each event specify name, trigger, producer, timestamp, customer key, product IDs, value, currency, order state, latency target, deduplication key, sample payload, owner, and failure monitor.

Core events may include subscription, viewed product, added to cart, began checkout, placed order, fulfilled order, delivered order, refund, cancellation, return, support state, and inventory state.

## Seven-flow architecture

### F01 Welcome and first purchase

Enter on valid channel consent. Branch by declared interest or source where lawful. Exit on purchase, withdrawal, invalid address, or suppression. Deliver promised value before promotion.

### F02 Cart and checkout recovery

Enter on current cart or checkout state. Confirm the customer has not purchased. Lead with continuity and help, then proof, then an approved offer only when justified. Exit immediately on purchase or invalid cart.

### F03 Browse recovery

Use a higher intent threshold than a single accidental view. Respect availability and price freshness. Avoid treating low-intent browsing as a checkout.

### F04 Post-purchase and onboarding

Branch by fulfillment and delivery state. Set expectations, reduce misuse, improve successful adoption, collect insight, and request a review only after a credible use interval.

### F05 Winback

Trigger from observed replenishment or repeat interval, not a universal number of days. Separate reminder, value, feedback, and offer roles. Exit on purchase or active service issue.

### F06 Sunset and suppression

Use one low-pressure preference or re-engagement attempt, then suppress persistent non-engagers. Treat machine-generated opens cautiously.

### F07 VIP recognition

Define value using delivered contribution, repeat behavior, service cost, and returns, not gross revenue only. Use recognition, access, and service before blanket discounting.

## Collision and priority

Maintain a matrix across transactional, service, safety, post-purchase, cart, browse, campaign, winback, and VIP messages. Transactional and service-critical messages normally outrank promotional flows. Define mutual exclusions and global frequency caps.

## Copy contract

Each message has one job, current state, subject or opening, body, product and offer data source, CTA, fallback, disclosure, accessibility, and exit effect. Dynamic fields require readable fallbacks.

## Measurement

Define eligible population, delivered population, control or holdout, purchase window, return and refund maturity, margin basis, and channel cost.

Incremental orders = eligible customers x (treatment purchase rate - control purchase rate).

Incremental CM2 = incremental delivered orders x CM2 per delivered order - incremental messaging cost.

Do not use attributed revenue as proof of incrementality.
