# Retention Decision Rules

## Activation blockers

Block when any of these are unresolved:

- channel consent or revocation propagation
- customer identity or deduplication
- event accuracy, latency, or order-state correctness
- purchase exit
- suppression and frequency cap
- product, price, availability, offer, or policy data
- sender authentication or required unsubscribe behavior

## Flow priority

Service, safety, payment, order, and account-critical messages take precedence over promotion. Pause or suppress promotional flows during active complaint, cancellation, refund, fraud, safety, or severe delivery states when appropriate.

## Discount use

Use a discount only when the flow role, customer state, economic guardrail, eligibility, stacking, expiry, and no-purchase alternative are explicit. Do not train every abandoned session to wait for a code.

## Cart and browse

Exit on purchase, empty or expired cart, unavailable product, invalid consent, or suppression. Refresh price and inventory at send time. Browse flow needs a repeated or meaningful signal.

## Post-purchase

Do not ask for a review before delivery and credible use. Do not cross-sell before essential setup, shipping, or support uncertainty is resolved.

## Winback

Base timing on observed repeat interval by product or cohort. Separate customers who no longer need the product from customers who had a bad experience.

## Sunset

Use click, site, purchase, and other reliable engagement signals. Treat opens as uncertain where machine privacy behavior is material. Suppression is a positive deliverability outcome, not failure.

## Testing

Require mutually exclusive groups, stable eligibility, event and offer parity, a maturity window, refund and margin view, and a predeclared decision rule. Do not contaminate holdouts with overlapping messages.

## Incidents

Pause affected journeys when an incorrect price, expired offer, duplicate send, consent failure, wrong customer data, unsafe claim, or broken exit is detected. Preserve logs and follow the approved incident process.
