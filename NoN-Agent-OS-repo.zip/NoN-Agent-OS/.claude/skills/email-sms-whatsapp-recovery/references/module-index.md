# Email, SMS & WhatsApp Recovery Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/retention-decision-rules.md`: retention procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/retention-domain-playbook.md`: retention procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/retention-advanced-search-controls.csv`: retention controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/retention-d2c-controls.csv`: retention controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/retention-d2c-prompts.csv`: retention controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/retention-d2c-workflows.csv`: retention controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/retention-lifecycle-source-43.csv`: retention controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/retention-retention-source-46.csv`: retention controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
