# Email, SMS & WhatsApp Recovery Agent: domain playbook

## Decision contract

Plan welcome and incomplete-purchase journeys with meaningful timing, offers and suppression. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Separate welcome, browse, cart and submitted-unpaid checkout audiences.

Required working record: Segment and trigger matrix. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Reconcile purchase state before entry and before every message.

Required working record: Email, SMS and WhatsApp drafts. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Design immediate assistance, objection handling and later offer escalation within margin limits.

Required working record: Offer ladder. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Write channel-specific copy, destinations, expiry wording and suppression rules.

Required working record: Purchase and consent suppression. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Provide a trigger matrix, idempotency keys and a results ledger for human setup.

Required working record: Recovery measurement plan. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
