# Operator procedure: Email, SMS & WhatsApp Recovery Agent

Trigger: the operator starts a task with a completed intake.

1. Separate welcome, browse, cart and submitted-unpaid checkout audiences.
2. Reconcile purchase state before entry and before every message.
3. Design immediate assistance, objection handling and later offer escalation within margin limits.
4. Write channel-specific copy, destinations, expiry wording and suppression rules.
5. Provide a trigger matrix, idempotency keys and a results ledger for human setup.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
