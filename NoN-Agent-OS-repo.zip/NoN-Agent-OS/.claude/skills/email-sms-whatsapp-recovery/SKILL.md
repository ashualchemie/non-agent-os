---
name: email-sms-whatsapp-recovery
description: Plan welcome and incomplete-purchase journeys with meaningful timing, offers and suppression. Use for this role's ecommerce task with supplied evidence and tools.
---

# Email, SMS & WhatsApp Recovery Agent

Plan welcome and incomplete-purchase journeys with meaningful timing, offers and suppression.

## Load the task packet

- Read `inputs/intake-brief.md` for required fields and missing-input handling.
- Read `references/domain-playbook.md` for the role-specific procedure.
- Use `references/decision-rules.md` to handle claims, economics and authorization.
- Load only relevant supporting modules listed in `references/module-index.md`.
- Format the result with `outputs/output-template.md`; use `outputs/handoff-template.md` when another role must act.

## Execute one task

1. Separate welcome, browse, cart and submitted-unpaid checkout audiences.
2. Reconcile purchase state before entry and before every message.
3. Design immediate assistance, objection handling and later offer escalation within margin limits.
4. Write channel-specific copy, destinations, expiry wording and suppression rules.
5. Provide a trigger matrix, idempotency keys and a results ledger for human setup.

## Boundaries

- No real email or WhatsApp is sent by these files.
- Do not claim fake deadlines or invent coupon validity.
- Post-purchase marketing belongs to Repeat Purchase & LTV.
- Use verified Brand Brain facts. Name assumptions, evidence gaps and the observation date.
- Do not invent outcomes, source quotations, permissions or tool availability.
- Draft first. External changes require the operator's authorization.

## Handoffs

- Winning Offers/Bundles Generator Agent: pass the approved packet in `outputs/handoff-template.md`.
- Repeat Purchase & LTV Generator Agent: pass the approved packet in `outputs/handoff-template.md`.
- Operator Agent: pass the approved packet in `outputs/handoff-template.md`.
