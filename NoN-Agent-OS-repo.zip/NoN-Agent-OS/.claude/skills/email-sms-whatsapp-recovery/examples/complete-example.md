# Illustrative worked packet: Email, SMS & WhatsApp Recovery Agent

All example records, entities and timings below are illustrative. They explain the procedure and are not customer results or executed workflows.

## Supplied sample journey

Illustrative checkout CK-01 is submitted at 14:00. Payment reconciliation at 14:02 shows active/unpaid. The contact has permitted email delivery but no SMS or WhatsApp marketing permission. Approved offer rule OF-01 allows assistance first and a later discount within a stated margin floor.

## Trigger plan

| Stage | Entry | Draft purpose | Suppression |
|---|---|---|---|
| Assistance | Active/unpaid after the configured delay | Restore the checkout and answer payment questions. | Paid, cancelled, opted out or equivalent stage already sent. |
| Objection | Still unpaid at the next approved time | Explain the deliverable and remove one relevant uncertainty. | Same purchase and consent checks. |
| Offer | Still eligible under OF-01 | Use only the approved discount and real expiry. | Paid, expired offer, margin failure or already sent. |

## Email draft

Subject: "Your checkout is ready when you are"
Preview: "Pick up where you left off."
Body: "Your selected products are still in your checkout. Review the exact items and total, then continue to secure payment. If something stopped you, reply and tell us what happened."
CTA: the operator's signed recovery destination, never an invented link.

## Channel and dedupe rules

Do not send SMS or WhatsApp in this example because permission is absent. Message key: CK-01/recovery/assistance. Reconcile the order immediately before sending and after any provider failure. The files supply copy and configuration instructions; they do not send a message.

## Measurement

Record eligible checkouts, messages delivered, clicks, recovered paid orders, net revenue and offer cost. Open rate is directional and does not replace paid-order attribution.
