# Email, SMS & WhatsApp Recovery Agent: prompt cards

## Segment and trigger matrix

Using my completed intake and supplied evidence, prepare the segment and trigger matrix for this task. Follow the Email, SMS & WhatsApp Recovery Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Email, SMS and WhatsApp drafts

Using my completed intake and supplied evidence, prepare the email, sms and whatsapp drafts for this task. Follow the Email, SMS & WhatsApp Recovery Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Offer ladder

Using my completed intake and supplied evidence, prepare the offer ladder for this task. Follow the Email, SMS & WhatsApp Recovery Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
