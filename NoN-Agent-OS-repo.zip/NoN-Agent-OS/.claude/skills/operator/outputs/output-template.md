# Output: Operator Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Launch workback

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Experiment and operations backlog

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Task ownership register

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## SOP and workflow handoffs

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Stock and supplier review checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
