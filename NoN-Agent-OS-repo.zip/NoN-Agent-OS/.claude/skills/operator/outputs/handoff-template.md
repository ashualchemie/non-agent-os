# Handoff from Operator Agent

To agent/owner: 
Business decision: 
Input and evidence IDs: 
Approved output file: 
Offer/claim/policy constraints: 
Open questions: 
Proposed action: 
Authorization state: draft only / approved within stated scope
Due date and acceptance criteria: 

Suggested routes:

- Performance Marketing Agent: pass the approved packet in `outputs/handoff-template.md`.
- Profit, Attribution & Growth Agent: pass the approved packet in `outputs/handoff-template.md`.
- Customer Care Agent: pass the approved packet in `outputs/handoff-template.md`.
