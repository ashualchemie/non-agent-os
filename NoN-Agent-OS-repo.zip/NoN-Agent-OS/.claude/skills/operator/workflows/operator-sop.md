# Operator procedure: Operator Agent

Trigger: the operator starts a task with a completed intake.

1. Turn the goal into milestones, owners, dependencies and acceptance criteria.
2. Build one launch workback and an ordered experiment backlog.
3. Write SOPs with trigger, inputs, steps, exception routes and audit trail.
4. Review stock and supplier constraints before coordinating promotions.
5. Create handoff packets, status checkpoints and explicit authorization gates.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
