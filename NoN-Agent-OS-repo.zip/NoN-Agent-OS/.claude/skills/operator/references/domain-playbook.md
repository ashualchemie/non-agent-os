# Operator Agent: domain playbook

## Decision contract

Coordinate launches, experiments, SOPs, owners, stock reviews and supplier handoffs. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Turn the goal into milestones, owners, dependencies and acceptance criteria.

Required working record: Launch workback. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Build one launch workback and an ordered experiment backlog.

Required working record: Experiment and operations backlog. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Write SOPs with trigger, inputs, steps, exception routes and audit trail.

Required working record: Task ownership register. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Review stock and supplier constraints before coordinating promotions.

Required working record: SOP and workflow handoffs. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Create handoff packets, status checkpoints and explicit authorization gates.

Required working record: Stock and supplier review checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
