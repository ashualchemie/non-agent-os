# Supplier Research Domain Playbook

## 1. Specification lock

Create versioned requirements for function, material, composition, dimensions, tolerances, colour, finish, performance, compatibility, packaging, labelling, certifications, test methods, acceptable defect limits, target market, and documentation. Separate mandatory, preferred, negotiable, and prohibited requirements.

Every quote must state which specification version it covers. A lower quote for a different material, pack, test scope, or tolerance is not a comparable quote.

## 2. Candidate evidence register

For each candidate record legal name, trade name, domain, address, country, claimed role, production location, years stated, contact source, source dates, and independent verification. Record whether evidence proves identity, manufacturing capability, quality system, market compliance, capacity, and delivery history.

Use AI-027 and AI-028 principles for source ID, capture date, rights, hash or preserved copy, freshness, completeness, and representativeness.

## 3. Quote normalization

Normalize on one sellable unit and one currency.

- Product cost per unit
- Tooling allocation per expected usable units
- Custom packaging and print
- Required testing and certification
- Inspection and quality assurance
- Inland freight and export handling
- International freight and insurance
- Duty and import taxes where relevant
- Destination handling and last-mile inbound
- Payment fees and currency buffer

Landed unit cost = product + tooling allocation + packaging + test allocation + inspection + freight + insurance + duty + handling.

Cash exposure before sale = deposits + tooling + sample + testing + committed freight + duty + inventory paid before receipt.

Always show quote date, validity, incoterm, shipment size, weight or cube assumption, exchange rate, and exclusions.

## 4. Due diligence

Assess seven dimensions:

1. Identity and legal existence
2. Product and process capability
3. Quality system and traceability
4. Compliance evidence for target market
5. Capacity and lead-time evidence
6. Commercial terms and cash risk
7. Continuity, concentration, and communication risk

Use a 0 to 3 evidence score: 0 absent or conflicting, 1 self-asserted, 2 document or sample supported, 3 independently verified and current. Do not average away a mandatory failure.

## 5. Samples and inspection

Define golden sample, sample count, test methods, measurement tools, conditioning, packaging, destructive tests, acceptable deviations, photo evidence, reviewer, and disposition. Separate sample approval from production approval.

Production gates may include pre-production confirmation, in-process inspection, pre-shipment inspection, container loading evidence, retained sample, and receiving inspection. Set defect categories and limits with a qualified quality owner.

## 6. Lead time and capacity

Break lead time into confirmation, material procurement, tooling, pre-production sample, production, inspection, export readiness, freight, customs, and receiving. Record evidence for each component. Use low, base, and high cases. Capacity claims require a product-specific basis and current load context.

## 7. Shortlist and backup

Rank only candidates that pass mandatory gates. Show landed cost, cash exposure, evidence score, lead-time range, MOQ, quality risk, compliance state, concentration risk, unresolved questions, sample gate, and recommended role. A higher-cost verified backup may be preferable to an unverified cheapest option.

