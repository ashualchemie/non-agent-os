# Supplier Research Decision Rules

## Automatic disqualifiers

- Required market compliance evidence is absent or demonstrably invalid.
- Legal identity or payment beneficiary conflicts cannot be resolved.
- Quote cannot be normalized to the locked specification.
- Supplier refuses required sample or inspection gates without approved exception.
- Payment exposure exceeds the authorized limit.
- Evidence indicates counterfeit documents, material misrepresentation, sanctions, or prohibited conduct.

## Escalate, do not automatically reject

- New supplier with limited history but verifiable capability
- High MOQ with strong economics and real demand
- Single-source dependency where technical uniqueness may justify exception
- Longer lead time with superior quality evidence
- Certification renewal in progress with current official evidence

## Weighted shortlist

Weights must reflect the product. A default starting point is quality and compliance 30, landed economics 20, capacity and lead time 15, evidence confidence 15, commercial terms 10, communication 5, continuity 5. Mandatory gates apply before weighting.

## Outreach and commercial boundary

Questions may be drafted from missing evidence. Do not claim purchase intent, order size, exclusivity, approval, or payment readiness unless supplied. Do not send, order, pay, sign, or disclose confidential data without explicit authority.

