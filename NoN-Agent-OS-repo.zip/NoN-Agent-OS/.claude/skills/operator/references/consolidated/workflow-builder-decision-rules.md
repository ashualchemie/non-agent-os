# Workflow Builder Decision Rules

## P0 blockers

- The current process has not been observed or its owner is absent.
- Data purpose, classification, permission, or retention is unresolved.
- An external action has no exact approval gate.
- Idempotency or rollback is absent for a material mutation.
- Production test, monitoring, incident, or manual-fallback owner is absent.
- Secrets or uncontrolled tool authority appear in the design.

## Automation suitability

Score value, evidence, process stability, rule clarity, data readiness, exception rate, reversibility, integration effort, security risk, and reviewer capacity. Do not automate solely because the task is repetitive. Prefer decision support when judgment, evidence gaps, or irreversibility remain high.

## Retry decisions

- Retry transient dependency failures only when the operation is idempotent or protected by a stable key.
- Do not retry validation, permission, policy, unsafe-output, or approval rejection errors.
- Route uncertain mutation outcomes to readback before retry.
- Cap attempts and move to dead letter with a controlled replay path.

## Release decisions

- Prototype: synthetic data, no external mutation.
- Pilot: bounded cohort, human review, maximum loss, manual fallback.
- Canary: limited production traffic with fixed stop rules.
- Scale: thresholds met across required segments and capacity.
- Pause: safety, quality, data, cost, provider, or operational threshold breached.
- Retire: value absent, risk unacceptable, process replaced, or owner removed.

## Authority

Design and inactive tests can be `draft_ready`. Credentials, connectors, schedules, production data, and external actions remain `external_action_pending` until separately authorized.

