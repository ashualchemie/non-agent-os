# Stock Planning Domain Playbook

## 1. Data reconciliation

Create a SKU master with product, variant, unit, location, channel, status, case pack, MOQ, shelf life, and cost. Reconcile on-hand, reserved, damaged, quarantined, in-transfer, inbound, and available-to-promise definitions. Use STORE-003, STORE-006, STORE-007, STORE-011 to STORE-020, STORE-037, and STORE-039.

Map placed, paid, shipped, delivered, cancelled, RTO, refunded, replacement, test, and wholesale order states. Select the eligible demand state and explain it.

## 2. Demand cleaning

Flag:

- Stockout and low-availability periods
- Promotions, launches, price changes, and channel changes
- Bulk, influencer, wholesale, replacement, fraud, and test orders
- Returns that re-enter available stock
- Lost sales or waitlist signals
- Product substitutions and assortment changes

Do not automatically delete flagged periods. Separate them into components and preserve the reason.

## 3. Segmentation

Use ABC for value or contribution importance and XYZ for demand variability. Add lifecycle and risk labels such as hero, attach, seasonal, launch, exit, expiring, constrained, and single-source. Segmentation changes review frequency and method, not business truth.

## 4. Forecast scenarios

Choose a transparent baseline suitable for history and demand shape. Examples include recent moving average, weighted moving average, seasonal index, analogous product, or event build. Report backtest error when enough comparable history exists.

Build low, base, and high cases from explicit changes to baseline, promotion uplift, launch adoption, conversion, price, service, and cancellation assumptions. Keep planned demand separate from committed orders.

## 5. Lead time and inbound reliability

Measure purchase approval to supplier confirmation, production, inspection, dispatch, transit, customs, receiving, and usable availability. Use actual distributions and on-time-in-full evidence. Classify inbound as confirmed, at risk, or unverified.

## 6. Safety stock and reorder

The chosen method must match the data and service policy. A transparent option when both demand and lead time vary is:

Safety stock = z x square root of (average lead time x demand variance + average daily demand squared x lead-time variance).

If the data does not support this, use an approved simpler buffer and label it. Round suggested orders to case pack, then test MOQ, cash, shelf life, capacity, and storage.

## 7. Promotion and channel readiness

Split incremental demand from baseline. Reserve stock only after approval. Check offer eligibility, promotion dates, media spend, expected delivered demand, fulfilment capacity, customer-service fallback, substitute path, and stop rule. Use low, base, high demand and do not promise availability beyond approved stock.

## 8. Exceptions

Classify stockout risk, overstock, expiry, inbound delay, supplier concentration, cash breach, mapping defect, negative stock, stale stock, and forecast drift. Each exception needs owner, due date, action, expected evidence, exposure, alternative, and next review.

