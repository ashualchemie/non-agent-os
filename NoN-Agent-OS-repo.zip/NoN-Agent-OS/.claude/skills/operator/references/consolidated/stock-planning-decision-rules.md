# Stock Planning Decision Rules

## P0 blockers

- Stock balance or SKU mapping cannot be reconciled.
- Lead time is an unsupported point guess.
- Promotion demand exceeds approved available-to-promise stock without a fallback.
- Cash, shelf-life, storage, or regulatory limit is breached.
- Required supplier or inbound evidence is missing for a commitment.

## Replenishment decisions

- Reorder when projected position at receipt is below the approved reorder point and cash, shelf life, capacity, MOQ, and case-pack gates pass.
- Expedite only when the expected contribution or customer exposure exceeds expedite cost and the route is authorized.
- Reduce or defer when downside demand creates overstock, expiry, or cash risk.
- Transfer stock only after checking location demand, customer promise, transfer cost, and system readback.
- Do not reorder exit SKUs without a named exception.

## Uncertainty

Use ranges and sensitivity. A forecast is not a promise. When history is short, show analogous-product evidence and a wider range. When history is stockout-censored, report observed sales and estimated unconstrained demand separately.

## Approval

The planning packet may reach `draft_ready`. Any PO, transfer, inbound cancellation, availability change, or stock reservation remains `external_action_pending` until the exact action is approved.

