# Launch Planner Domain Playbook

## Launch contract

Define:

- launch type, market, product, variant, and customer
- target date, timezone, hard constraints, and flexible dates
- business outcome and decision metric
- margin, inventory, service, return, claim, policy, and cash guardrails
- offer and channel roles
- named launch owner and gate owners
- authorized and unauthorized external actions

## Work breakdown

Organize work into:

1. product and catalog truth
2. inventory and fulfillment
3. economics and offer
4. storefront and checkout
5. measurement and reporting
6. claims, policy, rights, and compliance review
7. creative and content
8. paid, owned, partner, and marketplace channels
9. customer care and incident response
10. launch-day command and post-launch learning

Each task needs an owner, duration or effort, dependency, acceptance evidence, approval, earliest start, due gate, status, and rollback implication.

## Critical path

Create a directed dependency map. A task is critical when delay shifts the launch-ready date and no usable float remains. Do not solve a critical-path conflict by assigning a false completion date.

Earliest finish = earliest start + duration.

Latest start = latest finish - duration.

Float = latest start - earliest start.

Critical tasks have zero or negative float on the current plan.

## Readiness gates

### Gate 1: truth

Product, variant, price, claims, rights, policies, and customer-facing terms reconcile.

### Gate 2: supply and operations

Sellable inventory, reservation, inbound confidence, fulfillment, shipping, returns, support, and incident ownership are ready.

### Gate 3: commerce and measurement

Page, cart, checkout, payment, events, attribution, revenue reconciliation, dashboards, and rollback pass.

### Gate 4: channel execution

Creative, copy, offers, destinations, audience rules, permissions, schedules, and approvals agree.

### Gate 5: launch command

Named command owner, monitor cadence, thresholds, pause authority, incident path, change log, and rollback are live.

## Risk model

Risk exposure = probability x impact.

Use 1 to 5 ordinal values only for prioritization. Record trigger, prevention, contingency, owner, and review date. A P0 blocker is not made acceptable by a low average score.

## Post-launch

Reconcile planned versus actual date, spend, inventory, orders, delivered contribution, returns, RTO, service, incidents, and learnings. Separate causal evidence from concurrent changes.
