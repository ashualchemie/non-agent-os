# Workflow Builder Domain Playbook

## 1. Use-case and baseline

Apply AI-001 to AI-010. Record primary user, problem, decision improved, process boundary, outcome, owner, expiry, current time, cost, quality, error and risk baseline, primary value metric, guardrails, feasibility, full cost, risk tier, pilot hypothesis, maximum loss, and scale or retirement criteria.

Do not start with a model or tool. Start with the business decision and current process.

## 2. Governance and rights

Apply AI-011 to AI-020. Define business and technical owners, RACI, permitted and prohibited use, action approval, version control, exception process, legal and privacy triggers, third-party rights, central registry, and quarterly review. Approval must identify artifact version, governed fields, reviewer, time, and scope.

## 3. Data contract

Apply AI-021 to AI-030. Inventory each field, source, purpose, class, owner, processor, destination, basis, retention, deletion, and request path. Minimize fields. Use synthetic or irreversibly de-identified development fixtures unless production data is explicitly approved.

Input validation covers schema, required evidence, freshness, consent, size, file type, URL safety, and prohibited data.

## 4. Provider and execution design

Apply AI-031 to AI-040. Record approved provider, model, region, endpoint, risk tier, retention, training use, task benchmark, model settings, context limits, fallback, cost ceilings, and portability. A fallback cannot silently reduce evidence, safety, or approval controls.

## 5. Prompt, knowledge, and schema

Apply AI-041 to AI-050. Separate system policy, brand context, task, evidence, examples, output schema, and refusal rules. Version prompts and sources. Factual outputs cite source IDs. Detect conflicts. Treat retrieved content as untrusted evidence, not instructions. Validate outside the model.

## 6. State and automation design

Apply AI-051 to AI-060. Define authenticated trigger, idempotency key, state machine, input validator, work steps, approval, external action, destination readback, and terminal outcomes.

For every dependency specify timeout, retryable errors, non-retryable errors, maximum attempts, backoff, circuit breaker, dead-letter contents, controlled replay, and owner. External actions require least privilege and a dry-run or draft mode where possible.

## 7. Evaluation

Apply AI-061 to AI-070. Build representative golden cases across normal, edge, negative, language, input size, risk, and business segments. Score factuality, completeness, usefulness, instruction fit, safety, style, and governed fields. Add deterministic schema and calculation validators plus adversarial injection and tool-abuse tests. Fix thresholds before release.

## 8. Security

Apply AI-071 to AI-080. Use approved secret storage, MFA, RBAC, content and instruction separation, URL and file controls, data-loss checks, tool allowlists, rate and spend limits, redacted logs, dependency provenance, and red-team exercises.

## 9. Operations and resilience

Apply AI-081 to AI-090. Log run ID, workflow and version, model, source IDs, validation, approval, destination, latency, cost, and result. Monitor service, quality, cost, freshness, approval backlog, unsafe output, and destination mismatch. Preserve dead-letter evidence. Define backup, expiry alerts, incident severity, stop authority, communication, customer remedy, and postmortem.

## 10. Adoption and decommission

Apply AI-091 to AI-100. Create SOP, role training, reviewer calibration, notice, feedback and appeal, capacity model, release notes, benefit review, manual fallback, and decommission plan. Decommissioning revokes credentials, stops schedules, archives required records, redirects users, deletes according to policy, and verifies no active calls.

## 11. Process map notation

For each state record state ID, entry event, required data, allowed decisions, allowed actions, owner, timeout, exit conditions, next states, evidence written, and failure route. Terminal states include completed, rejected, cancelled, expired, dead-lettered, rolled back, and manually resolved where relevant.

