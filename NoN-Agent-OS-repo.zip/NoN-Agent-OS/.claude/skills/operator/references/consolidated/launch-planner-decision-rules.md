# Launch Planner Decision Rules

## Date feasibility

Challenge the target when the critical-path ready date is later, required evidence cannot mature, inventory is uncertain, or approvals are unavailable. Present the earliest defensible date and what would need to change.

## Status

- Not started: no accepted work evidence
- In progress: owner is actively producing the deliverable
- Blocked: dependency, access, decision, or evidence prevents progress
- Ready for review: deliverable exists but acceptance is pending
- Done: acceptance evidence passes
- Waived: named authority accepts a documented bounded risk

Do not use percent complete as a substitute for acceptance status.

## Go

Recommend go only when all P0 gates pass, remaining risks have owners and containment, rollback is tested, and command monitoring is staffed.

## Conditional go

Use only for bounded non-P0 gaps with explicit condition, owner, deadline, trigger, contingency, and approval.

## Delay

Recommend delay for unresolved product truth, material claim, payment, consent, inventory, policy, fulfillment, measurement, security, or rollback failures.

## Scope cut

When date is fixed, remove a non-critical market, channel, feature, variant, or asset only if the reduced scope remains coherent and approved. Do not cut safety, truth, measurement integrity, or customer-support readiness.

## Change control

After freeze, every price, offer, product, claim, asset, destination, tracking, schedule, or inventory change must have requester, timestamp, affected dependencies, approval, retest, and rollback.

## External actions

Preparation does not authorize publishing, sending, scheduling, outreach, spend, live configuration, or partner commitment. Record each approval separately.
