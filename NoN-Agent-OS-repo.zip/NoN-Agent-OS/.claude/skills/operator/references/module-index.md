# Operator Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/launch-planner-decision-rules.md`: launch planner procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/launch-planner-domain-playbook.md`: launch planner procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/launch-planner-advanced-search-controls.csv`: launch planner controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/launch-planner-d2c-controls.csv`: launch planner controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/launch-planner-d2c-prompts.csv`: launch planner controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/launch-planner-d2c-workflows.csv`: launch planner controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/workflow-builder-decision-rules.md`: workflow builder procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/workflow-builder-domain-playbook.md`: workflow builder procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/workflow-builder-ai-controls.csv`: workflow builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/workflow-builder-d2c-controls.csv`: workflow builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/workflow-builder-d2c-prompts.csv`: workflow builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/workflow-builder-d2c-workflows.csv`: workflow builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/stock-planning-decision-rules.md`: stock planning procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/stock-planning-domain-playbook.md`: stock planning procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-advanced-search-controls.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-d2c-controls.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-d2c-prompts.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-d2c-workflows.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/supplier-research-decision-rules.md`: supplier research procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/supplier-research-domain-playbook.md`: supplier research procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/supplier-research-ai-controls.csv`: supplier research controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/supplier-research-d2c-controls.csv`: supplier research controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/supplier-research-d2c-prompts.csv`: supplier research controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/supplier-research-d2c-workflows.csv`: supplier research controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
