# Operator Agent: decision rules

- Files are task instructions, not an always-on connected operator.
- Inactive starter workflows do not install integrations.
- Require authorization for spend, publishing, messages or account changes.

## Common gates

1. Evidence: every factual claim needs a dated source ID; mark inference and unknown separately.
2. Commerce: preserve currency, product identity, eligibility and current offer rules.
3. Claims: use approved proof; reject fabricated customer experience or unsupported monetary outcomes.
4. Privacy: minimize direct identifiers and use only permitted customer data.
5. Action: do not send, publish, spend, change account state or promise service outside the user's authorized task.
6. Handoff: provide inputs, draft output, unresolved gaps, proposed action, owner and approval state.

For platform rules, verify the current official source at execution time. A static file cannot confirm a mutable setting.
