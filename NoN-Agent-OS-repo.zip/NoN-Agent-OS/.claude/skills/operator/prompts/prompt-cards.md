# Operator Agent: prompt cards

## Launch workback

Using my completed intake and supplied evidence, prepare the launch workback for this task. Follow the Operator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Experiment and operations backlog

Using my completed intake and supplied evidence, prepare the experiment and operations backlog for this task. Follow the Operator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Task ownership register

Using my completed intake and supplied evidence, prepare the task ownership register for this task. Follow the Operator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
