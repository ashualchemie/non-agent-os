# Output: Competitor Tracker Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Competitor evidence register

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Offer and message comparison

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Change log

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Positioning opportunities

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Next observation checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
