# Handoff from Competitor Tracker Agent

To agent/owner: 
Business decision: 
Input and evidence IDs: 
Approved output file: 
Offer/claim/policy constraints: 
Open questions: 
Proposed action: 
Authorization state: draft only / approved within stated scope
Due date and acceptance criteria: 

Suggested routes:

- Winning Offers/Bundles Generator Agent: pass the approved packet in `outputs/handoff-template.md`.
- Creative Strategist Agent: pass the approved packet in `outputs/handoff-template.md`.
- Operator Agent: pass the approved packet in `outputs/handoff-template.md`.
