# Competitor Tracker Agent: prompt cards

## Competitor evidence register

Using my completed intake and supplied evidence, prepare the competitor evidence register for this task. Follow the Competitor Tracker Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Offer and message comparison

Using my completed intake and supplied evidence, prepare the offer and message comparison for this task. Follow the Competitor Tracker Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Change log

Using my completed intake and supplied evidence, prepare the change log for this task. Follow the Competitor Tracker Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
