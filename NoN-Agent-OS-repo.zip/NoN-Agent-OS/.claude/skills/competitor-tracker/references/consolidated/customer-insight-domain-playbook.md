# Customer Insight Domain Playbook

## Research contract

Start with one decision, such as choosing a lead message, repairing an onboarding gap, or deciding whether two customer groups need different offers. Record the research question, audience boundary, market, time window, and intended use.

## Source register

Assign each record a stable ID:

CI-{source}-{date}-{sequence}

Capture source type, origin URL or system, observed date, authored date when known, customer stage, product, rating if applicable, permission, language, and redaction state.

Do not combine:

- organic reviews and incentivized reviews without a flag
- support tickets and general market demand as if they represent the same population
- multiple copies of the same review
- current evidence and stale evidence without a date field
- translated wording and original wording without preserving both

## Cleaning

1. Preserve raw text.
2. Remove exact and near duplicates into a duplicate map.
3. Flag spam, bot-like text, employee content, competitor content, and unverifiable testimonials.
4. Redact direct identifiers from working views.
5. Keep exclusions in a log with reason.
6. Separate usable corpus size from received corpus size.

## Coding frame

Code each usable record on:

- trigger or context
- desired progress
- functional, emotional, and social job
- barrier or anxiety
- alternative or workaround
- decision criterion
- proof sought or trusted
- product mechanism understood or misunderstood
- purchase, use, retention, or support stage
- outcome and unresolved issue
- exact phrase worth preserving

One record may carry multiple codes. Do not force every item into a theme.

## Theme and language synthesis

For each theme report:

- supporting record count and denominator
- distinct participant count when identity is safely available
- source types represented
- earliest and latest evidence date
- representative exact quotes
- counterevidence
- confidence
- decision implication

Sample share = supporting usable records / usable records in that source set.

Never present sample share as market share.

## Behavioral segment design

A segment must differ on at least two decision-relevant dimensions, such as trigger, job, barrier, proof threshold, urgency, purchase path, or retention behavior. For each segment define:

- inclusion and exclusion rule
- evidence IDs
- situation and trigger
- desired progress
- top barriers
- trusted proof
- message entry point
- offer or journey implication
- channel implication
- disconfirming evidence
- next validation test

Names should describe behavior, not caricature a person.

## Activation

Translate each insight into one controlled implication:

- message to test
- page or lifecycle change
- creative angle
- product or service improvement
- research follow-up

State the evidence and the signal that would disconfirm the implication.
