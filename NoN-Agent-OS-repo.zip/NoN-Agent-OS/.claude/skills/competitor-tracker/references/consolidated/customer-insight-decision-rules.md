# Customer Insight Decision Rules

## Evidence hierarchy

- Direct quote: exact, source-linked customer language
- Observation: explicit behavior or fact in the record
- Synthesis: pattern across multiple records
- Hypothesis: plausible explanation requiring a test

Never format a synthesis or hypothesis as a quote.

## Confidence

Assign High only when the theme has recent evidence from multiple independent source types, clear provenance, meaningful coverage within the sample, and limited contradiction.

Assign Medium when provenance is sound but source diversity, sample coverage, or recency is limited.

Assign Low when evidence is sparse, one-source, old, ambiguous, or materially contradicted.

Do not convert this rubric into false statistical certainty.

## Quote rules

- Keep wording exact, including errors, unless a translated version is separately labelled.
- Redact names, contact details, order IDs, and sensitive disclosures.
- Never reuse private support language in public marketing without an approved rights basis.
- Prefer short excerpts that preserve meaning.
- Label paid, gifted, employee, affiliate, or incentivized content.

## Contradictions

If customers disagree, identify the boundary condition. Possible boundaries include product variant, expertise, purchase stage, geography, device, use case, expectation, or service experience. Do not average away opposing needs.

## Segment acceptance

Accept a segment only if:

1. membership can be determined from available behavior or declared need,
2. it changes a meaningful decision,
3. it has more than one evidence record,
4. it does not rely on a protected trait, and
5. a test can validate or reject it.

## Sensitive evidence

Exclude health, financial, sexual, political, religious, biometric, precise-location, child, or other sensitive data from activation unless the user supplies a lawful, necessary, and approved use. Escalate rather than infer.

## Thin evidence

When fewer than two credible source types are available, deliver an exploratory insight memo plus a recruitment and evidence-gap plan. Do not produce definitive personas.
