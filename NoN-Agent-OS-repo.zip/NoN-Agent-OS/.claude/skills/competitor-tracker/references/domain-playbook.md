# Competitor Tracker Agent: domain playbook

## Decision contract

Organize dated competitor observations into a change log and defensible positioning opportunities. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Define watchlist, observation scope and capture date.

Required working record: Competitor evidence register. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Normalize each observed promise, mechanism, proof, offer, price and destination.

Required working record: Offer and message comparison. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Compare current evidence with previous observations; separate changes from unknowns.

Required working record: Change log. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Identify customer-relevant gaps we can credibly address.

Required working record: Positioning opportunities. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Create a dated change log and proposed positioning experiments.

Required working record: Next observation checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
