# Illustrative worked packet: Competitor Tracker Agent

All example records, entities and timings below are illustrative. They explain the procedure and are not customer results or executed workflows.

## Input evidence

Illustrative watchlist: Store A, Store B and Store C. Observation window: 1 to 4 October. The operator supplies capture A-01 of Store A's product page, B-01 of Store B's offer page and C-01 of Store C's ad. No spend or revenue data is supplied.

## Observation register

| Store | Evidence | Observed fact | Unknown |
|---|---|---|---|
| A | A-01, 4 Oct | A two-product routine is offered with a single checkout CTA. | Sales volume and margin. |
| B | B-01, 4 Oct | Shipping eligibility is displayed beside the offer. | Conversion impact. |
| C | C-01, 4 Oct | The ad opens on a product-use demonstration. | Spend, duration and effectiveness. |

## Change log

A previous Store B capture from 1 October did not show the shipping threshold. Record this as a visible messaging change, not proof of a business result. Store A and C have no prior capture, so their change status is unknown.

## Positioning opportunity

Customer evidence CV-03 asks which two products work together. If our SKU compatibility is verified, propose an easy-to-choose routine bundle. The opportunity follows customer uncertainty and observed market presentation; it does not imply competitor success.

## Decision and next run

Hand the opportunity to Winning Offers/Bundles for economics and Creative Strategist for a differentiating brief. Ask the operator to capture the same three destinations on the next scheduled observation date. No monitor is configured by the package.
