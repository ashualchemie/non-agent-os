# Inactive packet starters

These optional n8n JSON files validate inputs and prepare an AI task packet. They contain no configured credentials, do not call an AI model and do not publish or send. Importing them does not create a working integration. Configure only the tools you own and authorize, then review the resulting packet before external execution.
