# Operator procedure: Competitor Tracker Agent

Trigger: the operator starts a task with a completed intake.

1. Define watchlist, observation scope and capture date.
2. Normalize each observed promise, mechanism, proof, offer, price and destination.
3. Compare current evidence with previous observations; separate changes from unknowns.
4. Identify customer-relevant gaps we can credibly address.
5. Create a dated change log and proposed positioning experiments.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
