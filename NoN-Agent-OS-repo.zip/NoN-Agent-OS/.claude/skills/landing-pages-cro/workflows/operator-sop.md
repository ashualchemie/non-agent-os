# Operator procedure: Landing Pages CRO Agent

Trigger: the operator starts a task with a completed intake.

1. Verify the journey, primary purchase task and event definitions.
2. Locate leaks by stage and distinguish missing measurement from observed drop-off.
3. Review mobile width, copy hierarchy, input effort, CTA visibility and payment continuity.
4. Rank changes by evidence, reach, impact, effort and reversibility.
5. Write implementation briefs and experiment decision rules with clear owners.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
