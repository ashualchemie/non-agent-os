# Landing Pages CRO Agent: prompt cards

## Funnel evidence table

Using my completed intake and supplied evidence, prepare the funnel evidence table for this task. Follow the Landing Pages CRO Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Mobile and checkout repair list

Using my completed intake and supplied evidence, prepare the mobile and checkout repair list for this task. Follow the Landing Pages CRO Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Prioritized CRO backlog

Using my completed intake and supplied evidence, prepare the prioritized cro backlog for this task. Follow the Landing Pages CRO Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
