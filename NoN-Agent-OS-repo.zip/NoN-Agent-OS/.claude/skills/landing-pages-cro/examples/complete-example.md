# Illustrative worked packet: Landing Pages CRO Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All names and numbers in this example are illustrative.

## Intake

Brand: Cedar & Loom  
Market: India  
Currency: INR  
Mode: rapid triage  
Scope: mobile home, collection, hero PDP, cart, checkout, UPI failure, confirmation  
Authorization: browse and test cart allowed, no real order

Evidence included a 14-day commerce export, analytics export, two event traces, three mobile recordings, and current shipping and returns pages.

## Reconciliation

Commerce showed 1,240 orders. Analytics showed 1,302 purchases. Variance:

(1,302 - 1,240) / 1,240 x 100 = 5.0%.

Reloading the test confirmation state generated a second purchase event with the same order ID. CRO-001 was Fail with grade A evidence. Because no real order was authorized, payment capture and refund propagation remained Not Assessed.

## Selected findings

| Finding | Control | Status | Evidence | Observation |
|---|---|---|---|---|
| SA-F01 | CRO-001 | Fail | SA-20260926-measurement-001 | Confirmation reload emitted duplicate purchase |
| SA-F02 | CRO-063 | Partial | SA-20260926-pdp-003 | Delivery estimate appeared only after add to cart |
| SA-F03 | STORE-023 | Fail | SA-20260926-collection-002 | Material filter did not map to catalog values |
| SA-F04 | CRO-092 | Blocked | SA-20260926-trust-004 | Claim ledger was not provided |

## Score

The sample assessed 12 applicable controls. Weighted denominator was 38. Weighted achieved points were 23.5.

Weighted score = 23.5 / 38 x 100 = 61.8%.

Coverage = 12 / 18 applicable controls x 100 = 66.7%.

Both figures were reported. The untested six controls did not silently reduce or increase the score.

## First three tickets

1. SA-T01, P0: Gate browser and server purchase events on immutable order ID. Acceptance: five reload and back-navigation attempts produce one purchase per destination. Owner: analytics engineering.
2. SA-T02, P1: Surface pincode-aware delivery range on the PDP before add to cart. Acceptance: supported and unsupported pincodes show consistent PDP, cart, and checkout states. Owner: storefront engineering.
3. SA-T03, P1: Normalize material taxonomy and rebuild the collection filter. Acceptance: every displayed option returns only matching, available products and survives back navigation. Owner: merchandising.

Release recommendation: proceed with containment only after SA-T01 is verified. No claim-compliance conclusion was made because CRO-092 was blocked.
