# Landing Pages CRO Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/store-audit-decision-rules.md`: store audit procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/store-audit-domain-playbook.md`: store audit procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/store-audit-advanced-search-controls.csv`: store audit controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/store-audit-d2c-controls.csv`: store audit controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/store-audit-d2c-prompts.csv`: store audit controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/store-audit-d2c-workflows.csv`: store audit controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/weekly-growth-decision-rules.md`: weekly growth procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/weekly-growth-domain-playbook.md`: weekly growth procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-d2c-controls.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-d2c-prompts.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-d2c-workflows.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
