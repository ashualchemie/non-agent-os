# Weekly Growth Domain Playbook

## Metric contract

Every metric requires name, business question, owner, source, formula, numerator, denominator, currency, timezone, order state, attribution basis, refund and cancellation treatment, update cadence, and change log.

Core formulas:

Conversion rate = delivered or accepted orders, as defined, / eligible sessions.

AOV = net merchandise revenue / orders on the same basis.

CAC = variable acquisition spend / acquired customers on the declared attribution basis.

MER = net revenue / acquisition spend.

CM1 = net collected revenue - variable costs before acquisition.

CM2 = CM1 - variable acquisition cost.

Never mix placed-order revenue with delivered-order costs without an explicit bridge.

## Reconciliation

Start with the commerce system as the order-state source and reconcile analytics and channel systems to it. Check timezone, currency, duplicate IDs, taxes, shipping, discounts, cancellations, refunds, RTO, COD, and attribution windows.

Variance = source value - system-of-record value.

Variance rate = variance / system-of-record value.

Do not use a universal tolerance. Use the approved business tolerance and explain each material difference.

## Revenue bridge

For a simple identity:

Revenue = eligible traffic x conversion rate x AOV.

Decompose changes sequentially using the same base or use a clearly documented bridge so traffic, conversion, and AOV effects sum to the observed change. Add delivered-order, cancellation, return, RTO, and margin bridges before concluding that gross growth is healthy.

## Constraint tree

Inspect:

1. measurement integrity
2. demand and traffic mix
3. landing and site conversion
4. product and inventory availability
5. price and offer
6. payment and checkout
7. fulfillment, cancellation, RTO, and returns
8. repeat purchase and lifecycle
9. unit economics and cash

For each candidate state evidence for, evidence against, confidence, and the smallest next test.

## Weekly decision memo

Produce exactly:

- one primary constraint
- one significant win
- one anomaly requiring follow-up
- up to five owned actions
- experiments to start, continue, stop, or read later
- decisions and rejected alternatives

## Meeting operating system

Pre-read before the meeting. Use meeting time for disputed evidence, decisions, owner commitment, and risk. Preserve a decision log with timestamp, basis, owner, expected signal, review date, and reversal condition.
