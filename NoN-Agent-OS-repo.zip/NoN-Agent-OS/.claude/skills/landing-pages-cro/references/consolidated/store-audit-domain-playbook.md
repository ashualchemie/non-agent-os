# Store Audit Domain Playbook

## Evidence model

Create an evidence ID for every observation:

SA-{date}-{journey}-{sequence}

Each record must contain URL or system, timestamp, locale, device, viewport, login state, experiment state, method, result, artifact path, and tester. A statement such as "checkout is confusing" is not evidence. A valid record states the task, observed behavior, affected cohort, and reproducible steps.

Evidence grades:

- A: transaction, raw event, server record, field data, or repeatable instrumented test
- B: reproducible browser or device test with artifact
- C: dated screenshot or documented stakeholder evidence
- D: inference or unverified report

Only A or B can close a P0 control. C can open a finding. D must be labelled hypothesis.

## Audit layers

### Measurement and identity

Use CRO-001 through CRO-011 and STORE-051 through STORE-056. Reconcile order count and net revenue across commerce and analytics for complete days. Inspect duplicate purchase events, currency, refund behavior, attribution persistence, consent state, cohort dimensions, experiment exposure, and error observability.

### Performance and accessibility

Use CRO-012 through CRO-033 and STORE-024 through STORE-030. Combine field data with representative lab runs. Test keyboard, focus, contrast, alternatives, forms, error recovery, zoom, drawers, motion preference, status announcements, low-end mobile, and constrained networks.

### Discovery and product choice

Use CRO-034 through CRO-066 and STORE-011 through STORE-030. Test message match, navigation, search, misspellings, zero results, filters, comparison, variant selection, media, product facts, delivery, returns, reviews, and inventory truth.

### Offer, cart, and checkout

Use CRO-067 through CRO-088 and STORE-001 through STORE-010 plus STORE-031 through STORE-040. Verify discount arithmetic, contribution guardrails, bundle logic, coupon behavior, totals, address entry, serviceability, UPI, COD, failure recovery, confirmation, and financial reconciliation.

### Trust, operations, and lifecycle

Use CRO-089 through CRO-110 and STORE-041 through STORE-060. Verify seller identity, claims evidence, policies, shipping promise, NDR, privacy operations, dark patterns, returns, lifecycle state accuracy, test governance, rollback, and accountable weekly review.

## Scoring

Map status to value:

- Pass = 1
- Partial = 0.5
- Fail = 0
- Blocked and Not Assessed = excluded

Map priority to weight:

- P0 = 5
- P1 = 3
- P2 = 1

Weighted score = sum(status value x priority weight) / sum(priority weight for assessed controls) x 100.

Always report assessed coverage beside the score:

Coverage = assessed applicable controls / applicable controls x 100.

Never compare two audit scores unless scope and coverage are materially comparable.

## Prioritization

For backlog ordering, score each issue:

Priority index = customer impact x journey reach x evidence confidence x urgency / effort.

Use bounded 1 to 5 inputs and show each input. P0 safety, payment, consent, duplicate-purchase, or order-integrity failures override the computed rank.

## Ticket contract

Each ticket requires control ID, evidence ID, affected cohort, current behavior, target behavior, remediation, owner role, dependency, acceptance test, rollback note, and due gate. Avoid vague tickets such as "improve checkout."
