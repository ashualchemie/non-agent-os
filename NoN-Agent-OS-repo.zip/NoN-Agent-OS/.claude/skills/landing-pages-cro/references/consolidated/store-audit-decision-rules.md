# Store Audit Decision Rules

## Status rules

- Pass only when current evidence meets the exact pass standard.
- Partial when part of the standard is met or the issue affects a bounded cohort.
- Fail when the observed state contradicts the standard.
- Blocked when the test is authorized but cannot be completed because access, data, or tooling is unavailable.
- Not Assessed when outside scope, unauthorized, or no credible test was performed.
- Not Applicable only when the business model makes the control irrelevant and the reason is recorded.

## Automatic P0 escalation

Escalate before optimization when any of these occur:

- duplicate or missing purchase events
- incorrect price, tax, discount, shipping, refund, or currency
- inability to complete a supported payment path
- unsupported or unsubstantiated customer-facing claim
- consent choice ignored by non-essential tracking
- customer or payment data exposed
- checkout progress lost after recoverable validation error
- inaccurate availability or delivery promise on an active SKU
- live experiment without exposure integrity or guardrails

## Evidence conflicts

When sources disagree:

1. Preserve both records.
2. Prefer transaction and server evidence over screenshots.
3. Check timezone, currency, cancellation, refund, and attribution bases.
4. State the unresolved difference.
5. Do not average incompatible numbers.

## Sampling

- Test at least one hero SKU, one long-tail SKU, one discounted SKU, and one constrained or unavailable SKU when they exist.
- Cover the highest-volume mobile path and one desktop path.
- Include logged-out, returning, and relevant regional states.
- Test every active payment method only when explicitly authorized.

## Remediation sequence

1. Contain customer or financial harm.
2. Restore measurement and state integrity.
3. Remove purchase blockers.
4. Repair trust and accessibility failures.
5. Improve discovery and persuasion.
6. Run optimization experiments only after the baseline is stable.

## Claim language

Use "observed," "not observed," "not tested," and "could not verify." Avoid "compliant," "certified," or "guaranteed."
