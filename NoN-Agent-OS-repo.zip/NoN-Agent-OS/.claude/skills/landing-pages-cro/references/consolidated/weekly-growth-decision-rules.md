# Weekly Growth Decision Rules

## Source conflict

When systems disagree:

1. preserve each source and its basis
2. reconcile time, currency, order state, tax, shipping, discounts, refunds, duplicates, and attribution
3. choose a source of truth by metric definition, not convenience
4. quantify unresolved variance
5. block causal or budget decisions when the variance could change the conclusion

## Material movement

Assess absolute change, relative change, sample size, normal variation, data maturity, seasonality, and concurrent changes. Do not label every week-over-week movement significant.

## Constraint acceptance

Name a primary constraint only when:

- measurement is sufficiently stable
- the constraint explains a material share of the outcome
- segment evidence supports it
- plausible alternatives were checked
- one action or test can discriminate the diagnosis

Otherwise state multiple hypotheses and a data plan.

## Causality

Use "associated with" when evidence is observational. Use causal language only for a valid experiment or a clear mechanical relationship. Record concurrent price, stock, site, tracking, budget, audience, creative, policy, and operational changes.

## Experiment state

- Start: hypothesis and run conditions are ready.
- Continue: minimum evidence is not mature and guardrails pass.
- Stop: harm, invalid setup, or predeclared futility rule.
- Decide: evidence matured and decision rule is met.
- Inconclusive: integrity or power is insufficient.

## Action quality

An action requires issue, exact next step, owner, due gate, expected signal, guardrail, dependency, and evidence for closure. "Monitor" is not an action unless monitor, threshold, cadence, and response are explicit.

## External mutation

A decision memo may recommend a change. It does not authorize changing campaigns, budgets, price, inventory, site, messaging, or flows.
