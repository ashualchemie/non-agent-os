# Landing Pages CRO Agent: domain playbook

## Decision contract

Diagnose landing and checkout leaks and prioritize concise mobile improvements from supplied evidence. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Verify the journey, primary purchase task and event definitions.

Required working record: Funnel evidence table. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Locate leaks by stage and distinguish missing measurement from observed drop-off.

Required working record: Mobile and checkout repair list. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Review mobile width, copy hierarchy, input effort, CTA visibility and payment continuity.

Required working record: Prioritized CRO backlog. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Rank changes by evidence, reach, impact, effort and reversibility.

Required working record: Copy and layout brief. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Write implementation briefs and experiment decision rules with clear owners.

Required working record: Measurement and rollback plan. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
