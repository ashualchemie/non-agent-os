# Output: Landing Pages CRO Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Funnel evidence table

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Mobile and checkout repair list

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Prioritized CRO backlog

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Copy and layout brief

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Measurement and rollback plan

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
