# Creative Strategist Agent: prompt cards

## Concept matrix

Using my completed intake and supplied evidence, prepare the concept matrix for this task. Follow the Creative Strategist Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Angle and hook map

Using my completed intake and supplied evidence, prepare the angle and hook map for this task. Follow the Creative Strategist Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Production briefs

Using my completed intake and supplied evidence, prepare the production briefs for this task. Follow the Creative Strategist Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
