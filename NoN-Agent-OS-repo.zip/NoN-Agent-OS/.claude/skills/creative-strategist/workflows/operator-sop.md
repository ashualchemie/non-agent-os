# Operator procedure: Creative Strategist Agent

Trigger: the operator starts a task with a completed intake.

1. Separate the customer problem, concept, angle, execution, format and hook.
2. Identify awareness stage and the mechanism the creative must explain.
3. Map every claim and proof element to a supplied evidence ID.
4. Develop contrasting concepts with clear hypotheses and constants.
5. Assign static or UGC production briefs and planned learning criteria.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
