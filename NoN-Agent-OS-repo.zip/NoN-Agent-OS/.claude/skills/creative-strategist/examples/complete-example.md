# Illustrative worked packet: Creative Strategist Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All entities and performance figures are illustrative.

## Evidence

Product: Field Flask 750  
Customer tension: commuters want sufficient capacity without a bulky bottle.  
Evidence: CI-review-004, CI-interview-003, CI-support-011.  
Approved proof: exact dimensions, 750 ml capacity, product-in-bag demonstration.  
Blocked claim: leakproof, because the supplied test covered upright transport only.

## Concept AC-C01: The bag-space tradeoff

Current belief: carrying enough water requires a wide bottle.  
Desired belief: capacity and a slim profile can coexist.  
Proof: side-by-side dimension demonstration in a representative bag pocket.  
Disconfirming signal: viewers understand the dimensions but qualified landing-page behavior does not improve.

## Execution AC-B01: Product demonstration

Format: 9:16, 20 seconds.  
First frame: open commuter bag with a wide object blocking the laptop sleeve, then remove it.  
First line: "Your bottle should not take the whole bag."  
Beat 1: place Field Flask 750 in the documented pocket.  
Beat 2: overlay exact dimensions and 750 ml capacity.  
Beat 3: show included cleaning brush and cap parts.  
Proof line: "750 ml. Exact dimensions shown."  
CTA: inspect dimensions and delivery on the product page.

The brief does not use customer testimony or the word leakproof.

## Test

Control: existing product-on-white video.  
Treatment: AC-C01 demonstration.  
Primary variable: concept.  
Primary metric: delivered CM2 per eligible impression or the closest approved account-level decision metric.  
Supporting signals: landing-page view rate, product-page engagement, purchase rate, and support questions about size.  
Guardrails: claim complaints, returns citing size mismatch, stock, page conversion, and tracking health.  
Stop: any rights, claim, pack, price, or destination mismatch.

## Result interpretation example

Suppose the treatment has a higher click-through rate but the same landing-page view rate and lower product-page conversion. Do not call it a winner. First inspect page load, message continuity, audience, placement, and whether the visual implied a bag fit broader than the exact dimension proof.

Authorization state: concept development approved. Creator outreach, generation, publication, and spend remain unapproved.
