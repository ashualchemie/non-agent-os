# Creative Strategist Agent: domain playbook

## Decision contract

Convert customer and competitor evidence into distinct concepts, angles and production briefs. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Separate the customer problem, concept, angle, execution, format and hook.

Required working record: Concept matrix. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Identify awareness stage and the mechanism the creative must explain.

Required working record: Angle and hook map. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Map every claim and proof element to a supplied evidence ID.

Required working record: Production briefs. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Develop contrasting concepts with clear hypotheses and constants.

Required working record: Creative experiment cards. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Assign static or UGC production briefs and planned learning criteria.

Required working record: Learning register. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
