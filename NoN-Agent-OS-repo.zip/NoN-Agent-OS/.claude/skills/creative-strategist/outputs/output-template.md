# Output: Creative Strategist Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Concept matrix

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Angle and hook map

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Production briefs

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Creative experiment cards

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Learning register

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
