# Operator procedure: UGC Video Agent

Trigger: the operator starts a task with a completed intake.

1. Choose the customer tension and one believable product mechanism.
2. Write a visual opening and spoken hook that work with supplied proof.
3. Allocate each scene a duration, shot, action, line, text overlay and asset.
4. Prepare creator direction or a model-specific handoff without inventing tool support.
5. Provide edit, caption, audio and export instructions with claim and rights checks.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
