# UGC Video Agent: domain playbook

## Decision contract

Prepare hooks, scripts, timed storyboards, shot lists and video-model handoffs from supplied assets. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Choose the customer tension and one believable product mechanism.

Required working record: Hook options. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Write a visual opening and spoken hook that work with supplied proof.

Required working record: Timed script and storyboard. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Allocate each scene a duration, shot, action, line, text overlay and asset.

Required working record: Shot list. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Prepare creator direction or a model-specific handoff without inventing tool support.

Required working record: Creator or video-model handoff. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Provide edit, caption, audio and export instructions with claim and rights checks.

Required working record: Edit and export checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
