# Illustrative worked packet: UGC Video Agent

All example records, entities and timings below are illustrative. They explain the procedure and are not customer results or executed workflows.

## Supplied sample brief

Illustrative product: the same slim wallet. Verified sample facts PF-01: six-card capacity. Asset AS-01: front view; AS-02: permitted close-up product-use footage. No creator endorsement is supplied. Target: 15 seconds, 9:16.

## Timed storyboard

| Time | Visual | Spoken draft | Overlay |
|---|---|---|---|
| 0-3 s | Tight product close-up from AS-01. | "Still carrying a bulky wallet?" | "Slim your everyday carry" |
| 3-7 s | Approved footage AS-02 showing cards entering the wallet. | "This design holds six cards." | "Six-card capacity" |
| 7-11 s | Show the actual product profile from permitted assets. | "A simpler way to carry the essentials." | Product name |
| 11-15 s | Product hero plus destination CTA. | "See the details before you choose." | "Explore the wallet" |

## Production handoff

If a real creator is used, film only actions the product can perform. If a video model is used, provide exact asset IDs, each scene's start/duration and the model's documented input requirements. Do not invent an API or claim a generated action was filmed.

## Edit notes

Keep the opening understandable without audio. Place captions inside the safe area. Use permitted sound, consistent product identity and a final CTA matching the landing page. Verify the six-card wording against PF-01. The paid 200-template/50+avatar collection and swipe library are excluded.

## Next decision

Hand the draft to the operator for production approval, then to Performance Marketing for a controlled launch proposal. This example produces a handoff, not a finished or launched video.
