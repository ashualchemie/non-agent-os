# Output: UGC Video Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Hook options

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Timed script and storyboard

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Shot list

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Creator or video-model handoff

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Edit and export checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
