# UGC Video Agent: prompt cards

## Hook options

Using my completed intake and supplied evidence, prepare the hook options for this task. Follow the UGC Video Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Timed script and storyboard

Using my completed intake and supplied evidence, prepare the timed script and storyboard for this task. Follow the UGC Video Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Shot list

Using my completed intake and supplied evidence, prepare the shot list for this task. Follow the UGC Video Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
