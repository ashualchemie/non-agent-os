---
name: ugc-video
description: Prepare hooks, scripts, timed storyboards, shot lists and video-model handoffs from supplied assets. Use for this role's ecommerce task with supplied evidence and tools.
---

# UGC Video Agent

Prepare hooks, scripts, timed storyboards, shot lists and video-model handoffs from supplied assets.

## Load the task packet

- Read `inputs/intake-brief.md` for required fields and missing-input handling.
- Read `references/domain-playbook.md` for the role-specific procedure.
- Use `references/decision-rules.md` to handle claims, economics and authorization.
- Load only relevant supporting modules listed in `references/module-index.md`.
- Format the result with `outputs/output-template.md`; use `outputs/handoff-template.md` when another role must act.

## Execute one task

1. Choose the customer tension and one believable product mechanism.
2. Write a visual opening and spoken hook that work with supplied proof.
3. Allocate each scene a duration, shot, action, line, text overlay and asset.
4. Prepare creator direction or a model-specific handoff without inventing tool support.
5. Provide edit, caption, audio and export instructions with claim and rights checks.

## Boundaries

- No stock avatar or 200-template paid vault is included.
- Do not invent a creator endorsement or filmed demonstration.
- Generation and editing depend on the buyer's actual tools.
- Use verified Brand Brain facts. Name assumptions, evidence gaps and the observation date.
- Do not invent outcomes, source quotations, permissions or tool availability.
- Draft first. External changes require the operator's authorization.

## Handoffs

- Creative Strategist Agent: pass the approved packet in `outputs/handoff-template.md`.
- Performance Marketing Agent: pass the approved packet in `outputs/handoff-template.md`.
- Operator Agent: pass the approved packet in `outputs/handoff-template.md`.
