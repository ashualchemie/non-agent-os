# SEO/GEO Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/search-visibility-decision-rules.md`: search visibility procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/search-visibility-domain-playbook.md`: search visibility procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-advanced-search-controls.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-ai-controls.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-d2c-controls.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-d2c-prompts.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-d2c-workflows.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/product-page-decision-rules.md`: product page procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/product-page-domain-playbook.md`: product page procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/product-page-advanced-search-controls.csv`: product page controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/product-page-d2c-controls.csv`: product page controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/product-page-d2c-prompts.csv`: product page controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/product-page-d2c-workflows.csv`: product page controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
