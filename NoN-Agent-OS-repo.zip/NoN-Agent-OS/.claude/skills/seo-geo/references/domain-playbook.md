# SEO/GEO Agent: domain playbook

## Decision contract

Prepare buyer-intent search and answer-focused content, internal links and technical guidance. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Group queries by buyer job, purchase stage and product relevance.

Required working record: Buyer-intent question map. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Map product, category, comparison and question pages without cannibalization.

Required working record: Content and comparison briefs. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Write concise answer structures with sourced facts and useful comparisons.

Required working record: Internal-link plan. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Prepare title, description, internal-link and structured-data recommendations.

Required working record: Indexation and schema checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Record publication tasks and search/answer visibility observations without promising rankings.

Required working record: Visibility observation register. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
