# Output: SEO/GEO Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Buyer-intent question map

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Content and comparison briefs

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Internal-link plan

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Indexation and schema checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Visibility observation register

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
