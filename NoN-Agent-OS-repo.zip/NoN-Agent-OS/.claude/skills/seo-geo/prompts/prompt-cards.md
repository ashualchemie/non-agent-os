# SEO/GEO Agent: prompt cards

## Buyer-intent question map

Using my completed intake and supplied evidence, prepare the buyer-intent question map for this task. Follow the SEO/GEO Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Content and comparison briefs

Using my completed intake and supplied evidence, prepare the content and comparison briefs for this task. Follow the SEO/GEO Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Internal-link plan

Using my completed intake and supplied evidence, prepare the internal-link plan for this task. Follow the SEO/GEO Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
