# Illustrative worked packet: SEO/GEO Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All domains and values are illustrative.

## Evidence

The crawl covers 2,400 product URLs. A normalized comparison finds 184 in-stock pages whose visible price is INR 1,499 while JSON-LD still contains INR 1,799. The merchant feed contains INR 1,499. Thirty-two affected URLs are in the sitemap and receive impressions. Sources: EX-CRAWL-01, EX-GRAPH-01, EX-FEED-01, EX-GSC-01.

Query evidence also shows demand for comparison guidance. The team asks to publish 20 new comparison pages immediately.

## Finding

SEO-021, SEO-026, SEOX-048, and SEOX-054 fail for the affected template. This is a material offer-graph parity defect. Content expansion is not the first action because search and customer surfaces disagree on price.

## Ticket SV-T01

- Pattern: Product pages using the stale cached offer node.
- Affected set: Query product template records where visible price differs from normalized JSON-LD price.
- Owner: Commerce engineering.
- Acceptance: All 184 pages show identical visible, graph, and feed price after cache refresh; automated parity test passes on complete set.
- Monitoring: Daily normalized snapshot for price and availability.
- Rollback: Restore prior template version and disable the new offer serializer.
- Authorization: Pending.

## Content decision

Map the comparison queries now, but delay page production until parity is fixed and the proposed comparison methodology has approved product facts and fair scoring. Status: `external_action_pending` for SV-T01 and `draft_ready` for the query map.

