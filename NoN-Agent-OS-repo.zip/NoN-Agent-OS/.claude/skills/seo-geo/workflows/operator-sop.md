# Operator procedure: SEO/GEO Agent

Trigger: the operator starts a task with a completed intake.

1. Group queries by buyer job, purchase stage and product relevance.
2. Map product, category, comparison and question pages without cannibalization.
3. Write concise answer structures with sourced facts and useful comparisons.
4. Prepare title, description, internal-link and structured-data recommendations.
5. Record publication tasks and search/answer visibility observations without promising rankings.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
