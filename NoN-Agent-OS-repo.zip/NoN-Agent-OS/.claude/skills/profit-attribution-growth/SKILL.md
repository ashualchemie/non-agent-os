---
name: profit-attribution-growth
description: Reconcile orders, refunds and ad spend into contribution reporting and actionable growth diagnosis. Use for this role's ecommerce task with supplied evidence and tools.
---

# Profit, Attribution & Growth Agent

Reconcile orders, refunds and ad spend into contribution reporting and actionable growth diagnosis.

## Load the task packet

- Read `inputs/intake-brief.md` for required fields and missing-input handling.
- Read `references/domain-playbook.md` for the role-specific procedure.
- Use `references/decision-rules.md` to handle claims, economics and authorization.
- Load only relevant supporting modules listed in `references/module-index.md`.
- Format the result with `outputs/output-template.md`; use `outputs/handoff-template.md` when another role must act.

## Execute one task

1. Define eligible orders, customer cohort and matching keys.
2. Reconcile commerce, platform and financial totals and log every variance.
3. Calculate contribution, delivered CAC and break-even acquisition limits.
4. Inspect cohort, product, channel and journey differences with sample limits.
5. Write a weekly diagnosis, data repair queue and prioritized decision packet.

## Boundaries

- Attribution models can disagree without one being false.
- Never treat platform ROAS as profit.
- Do not double-count browser and server Purchase events.
- Use verified Brand Brain facts. Name assumptions, evidence gaps and the observation date.
- Do not invent outcomes, source quotations, permissions or tool availability.
- Draft first. External changes require the operator's authorization.

## Handoffs

- Performance Marketing Agent: pass the approved packet in `outputs/handoff-template.md`.
- Winning Offers/Bundles Generator Agent: pass the approved packet in `outputs/handoff-template.md`.
- Operator Agent: pass the approved packet in `outputs/handoff-template.md`.
