# Output: Profit, Attribution & Growth Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Reconciliation ledger

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Contribution and CAC report

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Attribution discrepancy log

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Cohort and product diagnosis

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Weekly growth decision packet

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
