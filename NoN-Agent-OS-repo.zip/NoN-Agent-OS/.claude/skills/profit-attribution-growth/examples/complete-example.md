# Illustrative worked packet: Profit, Attribution & Growth Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All entities and numbers are illustrative.

## Period and basis

Current: 2026-09-14 to 2026-09-20  
Comparison: prior seven days  
Timezone: Asia/Kolkata  
Currency: INR  
Revenue basis: net merchandise revenue from placed orders, with a separate delivered contribution bridge

## Integrity

Commerce: 1,000 placed orders.  
Analytics: 1,045 purchases.  
Variance: 45 orders, or 4.5% of commerce orders.

Event review found confirmation reload duplicates concentrated in one checkout route. Purchase-based channel conclusions were marked provisional. Commerce remained the order source of truth.

## Revenue identity

Prior week:

- 100,000 eligible sessions
- 2.0% conversion
- INR 1,000 AOV
- Revenue = 100,000 x 0.020 x 1,000 = INR 2,000,000

Current week:

- 110,000 eligible sessions
- 1.7% conversion
- INR 1,050 AOV
- Revenue = 110,000 x 0.017 x 1,050 = INR 1,963,500

Traffic rose 10%, but lower conversion more than offset most of the traffic gain. AOV partly recovered the decline.

## Segment evidence

The largest conversion decline occurred on mobile paid landing sessions for one hero SKU. Organic and returning-customer conversion were broadly stable. That SKU had a page release, slower median load, and two hours of unavailable inventory.

Primary constraint: mobile paid landing experience for the hero SKU.  
Confidence: Medium, because tracking duplicates affect purchase comparison.  
Evidence against: checkout completion among customers who began checkout remained stable.

## Win

Returning-customer CM2 per session improved after a replenishment-flow test, but the holdout had not yet reached return maturity. Decision: continue, do not scale.

## Anomaly

COD cancellation appeared lower, but current cohorts were not mature. Owner: operations analytics. Next check after the declared delivery and cancellation window.

## Actions

1. Fix duplicate purchase event and retest five confirmation states. Owner: analytics engineering.
2. Revert or repair the hero mobile page release. Owner: storefront engineering.
3. Reconcile hero-SKU stock state against campaign delivery. Owner: merchandising.
4. Hold the replenishment test until return maturity. Owner: lifecycle.

No campaign, budget, page, or flow change was executed from this memo.
