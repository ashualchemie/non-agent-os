# Profit, Attribution & Growth Agent: domain playbook

## Decision contract

Reconcile orders, refunds and ad spend into contribution reporting and actionable growth diagnosis. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Define eligible orders, customer cohort and matching keys.

Required working record: Reconciliation ledger. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Reconcile commerce, platform and financial totals and log every variance.

Required working record: Contribution and CAC report. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Calculate contribution, delivered CAC and break-even acquisition limits.

Required working record: Attribution discrepancy log. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Inspect cohort, product, channel and journey differences with sample limits.

Required working record: Cohort and product diagnosis. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Write a weekly diagnosis, data repair queue and prioritized decision packet.

Required working record: Weekly growth decision packet. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
