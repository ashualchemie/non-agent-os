# Profit, Attribution & Growth Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/weekly-growth-decision-rules.md`: weekly growth procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/weekly-growth-domain-playbook.md`: weekly growth procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-advanced-search-controls.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-d2c-controls.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-d2c-prompts.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/weekly-growth-d2c-workflows.csv`: weekly growth controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/paid-media-decision-rules.md`: paid media procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/paid-media-domain-playbook.md`: paid media procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-d2c-controls.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-d2c-prompts.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-d2c-workflows.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
