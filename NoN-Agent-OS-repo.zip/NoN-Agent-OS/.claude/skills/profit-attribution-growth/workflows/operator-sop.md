# Operator procedure: Profit, Attribution & Growth Agent

Trigger: the operator starts a task with a completed intake.

1. Define eligible orders, customer cohort and matching keys.
2. Reconcile commerce, platform and financial totals and log every variance.
3. Calculate contribution, delivered CAC and break-even acquisition limits.
4. Inspect cohort, product, channel and journey differences with sample limits.
5. Write a weekly diagnosis, data repair queue and prioritized decision packet.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
