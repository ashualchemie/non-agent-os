# Profit, Attribution & Growth Agent: prompt cards

## Reconciliation ledger

Using my completed intake and supplied evidence, prepare the reconciliation ledger for this task. Follow the Profit, Attribution & Growth Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Contribution and CAC report

Using my completed intake and supplied evidence, prepare the contribution and cac report for this task. Follow the Profit, Attribution & Growth Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Attribution discrepancy log

Using my completed intake and supplied evidence, prepare the attribution discrepancy log for this task. Follow the Profit, Attribution & Growth Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
