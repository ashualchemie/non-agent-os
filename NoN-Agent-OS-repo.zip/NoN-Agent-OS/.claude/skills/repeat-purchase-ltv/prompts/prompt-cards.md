# Repeat Purchase & LTV Generator Agent: prompt cards

## Cohort and reorder analysis

Using my completed intake and supplied evidence, prepare the cohort and reorder analysis for this task. Follow the Repeat Purchase & LTV Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Post-purchase journey map

Using my completed intake and supplied evidence, prepare the post-purchase journey map for this task. Follow the Repeat Purchase & LTV Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Cross-sell and replenishment rules

Using my completed intake and supplied evidence, prepare the cross-sell and replenishment rules for this task. Follow the Repeat Purchase & LTV Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
