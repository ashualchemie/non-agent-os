# Illustrative worked packet: Repeat Purchase & LTV Generator Agent

All example records, entities and timings below are illustrative. They explain the procedure and are not customer results or executed workflows.

## Supplied sample cohort

Illustrative customer cohort bought product A and has verified paid orders. Product B is compatible with A and has sufficient stock. The operator supplies contribution and marketing permission. No replenishment interval is observed.

## Journey decision

Start with helpful product-use guidance. Then offer compatible product B to customers who do not already own it, have no unresolved service issue and meet the approved contact rule. Do not invent a replenishment timer. Ask for reorder history before proposing a replenishment flow.

## Cross-sell draft

Subject: "The next step for your routine"
Body: "Already using product A? Product B is the compatible next step when you need [verified use case]. See how they work together and check the details before you decide." Replace the bracketed use case only with supplied product truth.
CTA: operator's verified product or personalized customer destination.

## Eligibility and suppression

Include verified A buyers with permitted contact. Exclude B owners, refunded/invalid orders, active service complaints, unavailable stock and expired offers. A later purchase rechecks eligibility before the next message.

## Cohort readout

Count paid repeat customers / eligible first-order customers within a fixed observation window. Report observed repeat revenue and contribution separately from projected lifetime value. Compare matched cohorts cautiously; this example is not a claim of uplift.

## Handoff

Winning Offers/Bundles approves any incentive. Customer Care owns individual issues. The Operator configures the actual lifecycle tools.
