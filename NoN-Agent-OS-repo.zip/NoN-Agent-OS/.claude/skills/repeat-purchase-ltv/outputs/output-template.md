# Output: Repeat Purchase & LTV Generator Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Cohort and reorder analysis

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Post-purchase journey map

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Cross-sell and replenishment rules

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Winback and VIP drafts

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## LTV learning ledger

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
