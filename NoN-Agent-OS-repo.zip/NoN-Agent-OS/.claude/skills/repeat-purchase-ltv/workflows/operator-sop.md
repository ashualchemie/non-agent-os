# Operator procedure: Repeat Purchase & LTV Generator Agent

Trigger: the operator starts a task with a completed intake.

1. Define retained revenue, repeat rate and cohort eligibility consistently.
2. Separate onboarding/service from promotional messages.
3. Build product-use, replenishment and cross-sell opportunities from evidence.
4. Set winback and VIP eligibility, margin floors and purchase suppression.
5. Prepare journey copy, content briefs and a cohort learning register.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
