# Repeat Purchase & LTV Generator Agent: domain playbook

## Decision contract

Plan second-order, replenishment, cross-sell, winback and VIP journeys from observed customer behavior. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Define retained revenue, repeat rate and cohort eligibility consistently.

Required working record: Cohort and reorder analysis. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Separate onboarding/service from promotional messages.

Required working record: Post-purchase journey map. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Build product-use, replenishment and cross-sell opportunities from evidence.

Required working record: Cross-sell and replenishment rules. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Set winback and VIP eligibility, margin floors and purchase suppression.

Required working record: Winback and VIP drafts. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Prepare journey copy, content briefs and a cohort learning register.

Required working record: LTV learning ledger. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
