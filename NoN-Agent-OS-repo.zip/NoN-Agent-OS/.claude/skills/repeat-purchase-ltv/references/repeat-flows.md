# Repeat Purchase & LTV Generator Agent: repeat flows

POST-PURCHASE: helpful use and onboarding guidance after verified payment. SECOND ORDER: complementary products the customer does not already own. REPLENISHMENT: observed or product-supported interval, not invented urgency. WINBACK: inactivity threshold matched to typical repeat cycle. VIP: explicit profitable-cohort eligibility. SUNSET: reduce or stop marketing to persistently unengaged contacts. Suppress unsuitable products, active service issues and expired offers.
