# Operator procedure: Performance Marketing Agent

Trigger: the operator starts a task with a completed intake.

1. Lock the measurement contract and reconcile platform, commerce and contribution ledgers.
2. Inspect Meta event deduplication, conversion optimization, audiences, placements and concept diversity.
3. Inspect Google conversion actions, product feeds, search terms, negatives and campaign role.
4. Separate traffic, creative, page, tracking, stock and economics causes.
5. Prioritize keep, pause, iterate and scale proposals with maturity and maximum-loss rules.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
