# Performance Marketing Agent: meta

Inspect objective, conversion location, event, maximize-conversions setting, attribution window, bid strategy, budgets, delivery state, audience/exclusions, placements and identity. Read back live settings before an authorized change. Diagnose Pixel/CAPI event-ID parity separately from reporting lag. Use concept-level creative records; do not infer a winner from a single purchase.
