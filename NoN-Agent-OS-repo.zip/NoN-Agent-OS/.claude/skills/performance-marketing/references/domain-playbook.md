# Performance Marketing Agent: domain playbook

## Decision contract

Analyze Meta and Google campaigns with reconciled metrics and prepare controlled optimization plans. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Lock the measurement contract and reconcile platform, commerce and contribution ledgers.

Required working record: Measurement contract. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Inspect Meta event deduplication, conversion optimization, audiences, placements and concept diversity.

Required working record: Meta diagnosis. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Inspect Google conversion actions, product feeds, search terms, negatives and campaign role.

Required working record: Google diagnosis. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Separate traffic, creative, page, tracking, stock and economics causes.

Required working record: Shared metrics dictionary. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Prioritize keep, pause, iterate and scale proposals with maturity and maximum-loss rules.

Required working record: Controlled change plan. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
