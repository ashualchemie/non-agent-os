# Marketplace Listing Decision Rules

## P0 blockers

- Current official platform or category rule source is missing.
- Required product identifier, compliance document, or safety fact is absent.
- Product facts or variant identity conflict.
- Fee basis is unknown for a price or promotion recommendation.
- Main image or claim rights are unverified.
- Inventory, availability, return, or fulfilment promise conflicts with operations.

## Listing action rules

- Create when identity, required fields, economics, inventory, assets, and policy gates pass.
- Revise when the listing is valid but incomplete, unclear, or not decision-useful.
- Split variations when children are materially different products or required variation attributes cannot express the difference.
- Merge or relate only when current rules permit it and product identity supports it.
- Pause a proposed promotion when downside contribution breaches the floor or stock cover is insufficient.
- Escalate policy, safety, legal, restricted-product, counterfeit, or identifier disputes to a qualified owner.

## Search-term rules

Each term must have evidence of relevance to the product and current category. Keep customer language, synonyms, use cases, and compatible attributes distinct from prohibited competitor marks, unsupported outcomes, and repeated terms. Label volume or trend data with source and date.

## Status

`blocked` applies to compliance, identity, fee, rights, or operational conflict. `draft_ready` applies to a complete offline packet. `external_action_pending` applies to upload, edit, price, variation, inventory, fulfilment, or promotion actions.

