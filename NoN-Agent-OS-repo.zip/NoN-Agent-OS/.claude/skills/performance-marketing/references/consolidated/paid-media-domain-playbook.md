# Paid Media Domain Playbook

## 1. Measurement contract

Record account IDs, market, timezone, currency, tax and shipping treatment, attribution window, conversion lag, new-customer definition, and eligible order state. For Meta, test Pixel and Conversions API parity, event ID deduplication, normalized permitted parameters, and domain continuity. For Google, classify conversion actions as Primary or Secondary, inspect enhanced conversions and consent behavior, and verify one transaction ID per successful order.

Use these D2C controls as anchors: PM-04 to PM-11 for Meta measurement, PM-28 to PM-32 for Google measurement, and CRO-001 to CRO-006 for cross-platform commerce validation.

## 2. Reconciliation

Create three ledgers:

1. Platform ledger: spend, attributed purchases, attributed value, attribution window, extraction time.
2. Commerce ledger: placed, paid, shipped, delivered, cancelled, RTO, partially refunded, fully refunded, fraud, and test orders.
3. Contribution ledger: net revenue, COGS, payment fee, fulfilment, shipping subsidy, expected or actual return and RTO cost.

Show variances rather than forcing agreement. A platform can legitimately claim more attributed orders than last-click commerce reporting, but duplicates, currency mismatch, missing refunds, or different transaction IDs are defects.

## 3. Metric dictionary

- CPM = spend / impressions x 1,000
- CTR = link clicks / impressions
- CPC = spend / link clicks
- Landing-page rate = landing-page views / link clicks
- Platform CVR = attributed purchases / landing-page views
- Platform CPA = spend / attributed purchases
- Delivered CAC = acquisition spend / eligible delivered new customers
- Platform ROAS = attributed value / spend
- Contribution before acquisition = net delivered revenue minus product, payment, fulfilment, shipping subsidy, return, and RTO costs
- Contribution after acquisition = contribution before acquisition minus acquisition spend
- Break-even CAC = contribution before acquisition per eligible new delivered customer

Every denominator must be named. Never mix all customers with new customers or placed orders with delivered orders.

## 4. Meta diagnosis

Use PM-12 to PM-25. Examine fragmentation, signal volume, bid strategy, exclusions, audience role, placement fit, catalog identity, concept diversity, claim approval, creative response, change history, and cohort contribution. Separate a learning-limited test from an underfunded evergreen campaign. Check that the active concept set spans different problems, awareness levels, mechanisms, proof types, formats, and offers.

## 5. Google diagnosis

Use PM-33 to PM-50. Check feed parity, product identifiers, merchant diagnostics, custom labels, search terms, campaign role, negatives, PMax goal and feed settings, asset-group coherence, final URL controls, bidding basis, pacing, and experiments. Do not treat asset ratings as causal performance evidence.

## 6. Creative fatigue

Assess by concept and audience, not filename. Review spend share, first-impression response, frequency, unique reach, click response, landing-page rate, purchase rate, delivered CAC, and time since material refresh. Classify:

- Distribution fatigue: reach stalls while response is stable.
- Message fatigue: response and conversion deteriorate after stable delivery.
- Audience saturation: frequency rises and marginal acquisition cost worsens in a constrained audience.
- False fatigue: tracking, offer, page, stock, or delivery changed.

## 7. Catalog and economics

Map advertised SKU, clicked SKU, purchased SKU, available stock, margin band, hero status, lifecycle, promotion eligibility, and content ID. Use PM-18, PM-25, PM-33 to PM-37, and PM-50. Exclude loss-making or unavailable products from acquisition unless a documented strategic exception exists.

## 8. Test design

Use WF-07 and PR-10. One card contains one primary variable, control, treatment, audience, destination, success metric, guardrail, budget, duration, maturity window, minimum practical effect, maximum loss, stop rule, and next decision. Use matched conditions where feasible. Do not make budget, bid, audience, offer, creative, and destination changes in one cell.

