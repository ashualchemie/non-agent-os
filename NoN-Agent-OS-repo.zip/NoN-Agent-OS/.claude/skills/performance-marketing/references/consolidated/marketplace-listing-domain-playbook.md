# Marketplace Listing Domain Playbook

## 1. Rule snapshot

Capture official platform URL, page title, category, seller region, access date, and the exact rule being applied. Classify each requirement as mandatory, conditional, recommended, prohibited, or unknown. Preserve evidence for identifiers, titles, bullets, descriptions, search terms, images, variations, safety, labelling, price, availability, shipping, returns, and fulfilment.

Rules change. Never rely on remembered character limits, image counts, or category requirements when the current decision depends on them.

## 2. Product identity and attributes

Use STORE-011 to STORE-020, SEO-019 to SEO-027, and SEOX-045 to SEOX-055. Create one governed identity record per sellable variant:

- Brand, product name, model, SKU, GTIN or MPN where applicable
- Parent and child relationship
- Size, colour, material, ingredients, compatibility, quantity, dimensions, and weight
- Regulatory, safety, labelling, origin, and warranty facts
- Pack contents and unit basis

Do not copy an attribute from a sibling variant unless the approved source states it applies.

## 3. Fee-aware economics

Normalize price and fees on one tax basis.

- Net sale = customer price minus seller-funded discount minus tax collected on behalf of authorities where applicable
- Marketplace contribution = net sale minus referral fee, closing or fixed fee, fulfilment fee, storage allocation, shipping subsidy, payment fee where applicable, COGS, packaging, expected return cost, and other item-level fees
- Break-even ad cost = marketplace contribution before marketplace advertising

Model base, downside, and promotion cases. Record effective dates and marketplace fee source.

## 4. Listing content

Title communicates identity and the most decision-critical differentiators without unsupported superlatives. Bullets move from fit and outcome to mechanism, proof, use, limitations, pack, and policy facts. Description resolves use and comparison questions not answered above. Backend terms add eligible language without duplication or prohibited claims.

Use SEO-010 to SEO-016, SEO-028 to SEO-036, and relevant CRO PDP and Trust controls. Search relevance never overrides truth or readability.

## 5. Image sequence

Assign roles rather than making a generic gallery:

1. Compliant main image
2. Product identity and included items
3. Scale, size, or fit
4. Key decision benefit with approved proof
5. Use or installation
6. Comparison or selection support
7. Material, ingredient, or detail
8. Policy, care, or compatibility where allowed

Every asset needs rights, variant accuracy, current packaging, and platform-compliant overlays.

## 6. Variation and duplicate logic

Create a parent only when children represent legitimate variations of one product family under current category rules. Check shared identity, distinguishing attribute, unique identifier, image accuracy, price, availability, and review treatment. Do not merge materially different products to borrow reviews.

## 7. Publish packet

Include field-by-field current and proposed values, rule source, product source, claim ID, asset ID, expected customer effect, rollback, owner, and authorization state. Store a normalized snapshot after separately authorized publishing for readback comparison.

