# Paid Media Decision Rules

## P0 blockers

- Duplicate purchases or non-unique transaction IDs
- Spend, currency, timezone, or account mismatch
- Platform revenue cannot be related to commerce orders
- Consent or ownership is unresolved
- Contribution basis is absent for a budget increase
- Proposed action exceeds the approved maximum loss
- Feed price or availability conflicts with the destination

## Decision tree

1. If spend does not reconcile, stop and repair extraction or account scope.
2. If orders do not reconcile, split attribution difference from data defect. Stop on duplicates or identity mismatch.
3. If contribution is unknown, permit diagnostic work but block scaling or bid recommendations.
4. If signal quality is broken, fix measurement before restructuring campaigns.
5. If landing-page rate falls while CTR is stable, inspect load, redirects, consent, and link continuity.
6. If CTR falls but downstream CVR is stable, inspect message fatigue, placement fit, and audience saturation.
7. If CVR falls across channels, inspect offer, page, price, stock, payments, and delivery before blaming media.
8. If platform ROAS is strong but delivered contribution is negative, reduce or pause the affected cohort subject to approval.

## Budget bounds

Set test maximum loss as the lower of the approved cash-risk limit and the expected loss under the downside case. A scaling proposal must state current spend, proposed spend, step size, observation window, conversion lag, inventory cover, break-even CAC, and rollback threshold.

## Status rules

- `requires_input`: missing data changes the decision.
- `blocked`: a P0 control fails.
- `draft_ready`: diagnosis and test slate are complete.
- `external_action_pending`: exact account changes are drafted but not authorized.
- `approved_for_handoff`: named reviewer approved the packet, not the account mutation.

