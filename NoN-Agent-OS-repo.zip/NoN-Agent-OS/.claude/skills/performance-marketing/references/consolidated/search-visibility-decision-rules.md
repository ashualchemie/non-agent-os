# Search Visibility Decision Rules

## P0 blockers

- Core pages are blocked, non-rendered, non-indexable, or canonicalized incorrectly.
- A security incident or manual action is unresolved.
- Visible price, availability, shipping, return, identifier, or offer facts conflict with structured data or merchant feed.
- Migration inventory or redirect ownership is absent.
- A material public claim lacks an approved fact source.

## Prioritization

Score each finding on a 1 to 5 scale:

- Discoverability impact
- Indexability or eligibility impact
- Business value of affected pages
- Breadth of the affected pattern
- Evidence confidence
- Reversibility, where 5 means easy to reverse

Priority score = impact x breadth x confidence, then use business value and reversibility as decision modifiers. Do not hide P0 items inside an average.

## Page decisions

- Keep and improve when page role, demand, inventory, and evidence are distinct.
- Consolidate when two pages serve the same intent without a meaningful decision difference.
- Noindex when a useful customer state should exist but should not compete in search.
- Redirect only when a clear successor exists.
- Retain temporarily unavailable product pages when the product is expected to return and the page preserves useful value.
- Retire discontinued products using demand, links, alternatives, support value, and legal record needs.

## Claim discipline

Use `observed`, `calculated`, `inferred`, or `hypothesized` labels. Search-console data does not prove ranking causality. A structured-data validation pass does not prove rich-result eligibility. An AI answer snapshot is not a population estimate.

