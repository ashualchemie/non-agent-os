# Search Visibility Domain Playbook

## 1. Technical discovery

Apply SEO-001 to SEO-009 and SEOX-001 to SEOX-011. Test one preferred origin, equivalent edge and origin output, deliberate status behavior, intended crawler access, rendered HTML, deterministic pagination, finite parameter policy, crawl depth, and monitored coverage errors. Sample by template and risk, not only by a few URLs.

Record URL, normalized URL, template, status, canonical target, index state, robots result, sitemap membership, internal-link depth, rendered fact presence, and last observed date.

## 2. Ecommerce information architecture

Apply SEOX-012 to SEOX-022 plus STORE-011 to STORE-020. Every indexable category or facet needs a distinct demand role and inventory set. Govern primary category paths, filter combinations, product ordering, temporary stockouts, permanent discontinuation, internal search opportunities, and related-content links. Avoid creating near-empty pages because a query exists.

## 3. On-page and template systems

Apply SEO-010 to SEO-018 and SEOX-023 to SEOX-044. Test titles, headings, main landmarks, page identity, unique decision support, stable metadata ownership, accordions, units, anchor text, content stages, cannibalization, methods, originality, decay, and archive decisions.

Content opportunity is not search volume alone. Score verified demand evidence, page-role fit, inventory, contribution potential, existing authority, effort, and risk. Label assumptions.

## 4. Product, offer, and policy graph

Apply SEO-019 to SEO-027 and SEOX-045 to SEOX-060. Validate stable identifiers, product family and variants, GTIN or MPN where applicable, visible price and availability, complex offers, preorder or backorder states, returns, shipping, reviews, loyalty eligibility, graph parity, merchant diagnostics, feed overrides, promotions, and image requirements.

Treat three sources as one truth set: visible page, structured data, and merchant feed. A material mismatch is a release blocker.

## 5. Answer readiness and AEO

Apply SEO-028 to SEO-040 and SEOX-067 to SEOX-077. Build a question taxonomy by decision type. An answer unit should provide a correct first sentence, minimum context, stable nouns, explicit units and basis, visible branch logic, fair comparison, FAQ priority, abstain state, and accessible structure. Create a gold-answer set with required facts and forbidden errors.

## 6. Entity trust and GEO

Apply SEOX-078 to SEOX-088. Maintain separate canonical records for brand, legal company, product, and program. Map each material claim to owned evidence and independent corroboration where it genuinely exists. A citation gap creates an asset opportunity, not permission to fabricate mentions. Preserve prompt, date, locale, model or surface, response, citation, and source context for AI answer snapshots.

## 7. Analytics and controlled learning

Apply SEOX-089 to SEOX-099. Govern joins between query, page, item, order, and contribution data. Keep branded classification versioned. Report search demand separately from business value. Evaluate organic landing contribution after cancellations, refunds, and returns. Annotate changes by URL and template. Use defensible comparison units and baseline-aware alerts.

## 8. Release, migration, and operations

Apply SEOX-100 to SEOX-110. Every change needs a ticket, accountable owner, preproduction safety, regression test, deployment plan, monitoring, rollback, and closure evidence. Migrations require complete URL inventory and mapping. Search incidents need severity and communication rules. Apps and agencies cannot silently rewrite search-critical output.

