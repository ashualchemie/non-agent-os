# Performance Marketing Agent: shared metrics

CPM = spend / impressions x 1000. Link CTR = link clicks / impressions. CPC = spend / link clicks. Landing-page rate = landing-page views / link clicks. CPA = spend / eligible attributed purchases. ROAS = eligible attributed revenue / spend. Contribution after acquisition = net eligible revenue minus product, payment, fulfilment, shipping, returns and acquisition costs. Label denominators and report uncertainty.
