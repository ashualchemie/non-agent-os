# Performance Marketing Agent: google

Separate Search, Shopping and Performance Max by purpose. Inspect Primary versus Secondary conversion actions, transaction IDs, enhanced conversion consent, product feed eligibility, search terms, negatives, budget pacing, landing URLs and campaign overlap. Asset ratings alone do not establish incremental performance.
