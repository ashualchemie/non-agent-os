# Performance Marketing Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/paid-media-decision-rules.md`: paid media procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/paid-media-domain-playbook.md`: paid media procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-advanced-search-controls.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-d2c-controls.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-d2c-prompts.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/paid-media-d2c-workflows.csv`: paid media controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/search-visibility-decision-rules.md`: search visibility procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/search-visibility-domain-playbook.md`: search visibility procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-advanced-search-controls.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-d2c-controls.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-d2c-prompts.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/search-visibility-d2c-workflows.csv`: search visibility controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/marketplace-listing-decision-rules.md`: marketplace listing procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/marketplace-listing-domain-playbook.md`: marketplace listing procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/marketplace-listing-advanced-search-controls.csv`: marketplace listing controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/marketplace-listing-d2c-controls.csv`: marketplace listing controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/marketplace-listing-d2c-prompts.csv`: marketplace listing controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
