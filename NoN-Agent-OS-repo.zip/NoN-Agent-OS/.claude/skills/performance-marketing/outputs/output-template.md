# Output: Performance Marketing Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Measurement contract

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Meta diagnosis

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Google diagnosis

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Shared metrics dictionary

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Controlled change plan

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
