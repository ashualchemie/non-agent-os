# Handoff from Performance Marketing Agent

To agent/owner: 
Business decision: 
Input and evidence IDs: 
Approved output file: 
Offer/claim/policy constraints: 
Open questions: 
Proposed action: 
Authorization state: draft only / approved within stated scope
Due date and acceptance criteria: 

Suggested routes:

- Creative Strategist Agent: pass the approved packet in `outputs/handoff-template.md`.
- Landing Pages CRO Agent: pass the approved packet in `outputs/handoff-template.md`.
- Profit, Attribution & Growth Agent: pass the approved packet in `outputs/handoff-template.md`.
