# Illustrative worked packet: Performance Marketing Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All values are illustrative.

## Inputs

Meta reports INR 300,000 spend, 1,050 purchases, and INR 1,260,000 value for 1 to 14 September. The commerce export contains 930 placed orders with the same campaign-tag family, 870 paid orders, 790 delivered orders, 52 RTO orders, and 28 cancellations. Of the delivered orders, 610 are eligible new customers. Net delivered revenue is INR 924,000. Product, payment, fulfilment, shipping subsidy, return, and RTO costs total INR 510,000.

Sources: EX-META-01, EX-ORDERS-01, EX-COST-01. Attribution: 7-day click and 1-day view. All data is illustrative.

## Calculations

- Platform CPA = 300,000 / 1,050 = INR 285.71.
- Platform ROAS = 1,260,000 / 300,000 = 4.20.
- Delivered new-customer CAC = 300,000 / 610 = INR 491.80.
- Contribution before acquisition = 924,000 - 510,000 = INR 414,000.
- Contribution after acquisition = 414,000 - 300,000 = INR 114,000.
- Break-even CAC = 414,000 / 610 = INR 678.69.

## Diagnosis

The platform view is not directly comparable with delivered acquisition because it includes attribution overlap, repeat orders, cancellations, and RTO. The campaign is contribution-positive on the illustrative basis, but the requested 50% budget increase cannot be approved yet because top-SKU stock cover is only nine days and the conversion lag is six days. Evidence: EX-STOCK-01 and EX-META-01.

## Test slate

Test PM-T01 keeps campaign, audience, offer, destination, and budget stable. It replaces one fatigued concept with a new problem-mechanism concept. Primary metric is delivered new-customer CAC after the six-day maturity window. Guardrails are contribution after acquisition above zero, complaint rate not worse than control, and top-SKU cover above 14 days. Maximum test loss is INR 30,000. Stop if mature delivered CAC exceeds INR 650 after the minimum sample or tracking fails.

## Decision

Status: `external_action_pending`. Approve the creative test packet for review. Do not increase the campaign budget until inbound stock is received and reconciled.

