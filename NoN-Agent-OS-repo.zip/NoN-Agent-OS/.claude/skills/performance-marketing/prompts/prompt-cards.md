# Performance Marketing Agent: prompt cards

## Measurement contract

Using my completed intake and supplied evidence, prepare the measurement contract for this task. Follow the Performance Marketing Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Meta diagnosis

Using my completed intake and supplied evidence, prepare the meta diagnosis for this task. Follow the Performance Marketing Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Google diagnosis

Using my completed intake and supplied evidence, prepare the google diagnosis for this task. Follow the Performance Marketing Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
