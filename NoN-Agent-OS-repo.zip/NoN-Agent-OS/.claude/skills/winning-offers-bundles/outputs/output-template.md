# Output: Winning Offers/Bundles Generator Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Offer scenario table

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Contribution worksheet

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Selected offer and rationale

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Stacking and eligibility rules

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Implementation and stock checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
