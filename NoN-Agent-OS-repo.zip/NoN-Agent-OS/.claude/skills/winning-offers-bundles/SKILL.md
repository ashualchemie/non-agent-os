---
name: winning-offers-bundles
description: Design offer and bundle scenarios that fit contribution margins, stock and customer motivations. Use for this role's ecommerce task with supplied evidence and tools.
---

# Winning Offers/Bundles Generator Agent

Design offer and bundle scenarios that fit contribution margins, stock and customer motivations.

## Load the task packet

- Read `inputs/intake-brief.md` for required fields and missing-input handling.
- Read `references/domain-playbook.md` for the role-specific procedure.
- Use `references/decision-rules.md` to handle claims, economics and authorization.
- Load only relevant supporting modules listed in `references/module-index.md`.
- Format the result with `outputs/output-template.md`; use `outputs/handoff-template.md` when another role must act.

## Execute one task

1. Lock currency, taxes, quantities and eligible order state.
2. Calculate contribution before acquisition for each candidate offer.
3. Compare bundle, quantity break, free shipping and gift scenarios.
4. Reject candidates below margin or stock constraints and record assumptions.
5. Write approved offer rules, exclusions, claim wording and operational handoffs.

## Boundaries

- Winning is a design objective, not a guaranteed outcome.
- Do not infer margins when costs are missing.
- Require approval before changing live price or discounts.
- Use verified Brand Brain facts. Name assumptions, evidence gaps and the observation date.
- Do not invent outcomes, source quotations, permissions or tool availability.
- Draft first. External changes require the operator's authorization.

## Handoffs

- Performance Marketing Agent: pass the approved packet in `outputs/handoff-template.md`.
- Email, SMS & WhatsApp Recovery Agent: pass the approved packet in `outputs/handoff-template.md`.
- Operator Agent: pass the approved packet in `outputs/handoff-template.md`.
