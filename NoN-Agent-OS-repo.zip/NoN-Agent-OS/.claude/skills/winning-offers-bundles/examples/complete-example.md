# Illustrative worked packet: Winning Offers/Bundles Generator Agent

The following sample uses illustrative inputs to explain a decision. It is not a customer result, proof of execution or a guarantee. Apply only the parts inside this agent's responsibility boundary.


All entities and numbers are illustrative.

## Customer job

First-time buyers want a complete two-step routine without choosing compatible items separately. Evidence IDs CI-review-014, CI-interview-006, and CI-support-021 support the job.

## Candidate

Starter Pair: one cleanser and one moisturizer for INR 1,149, tax inclusive. No code. Not stackable with subscription or employee pricing. Available to India D2C orders while both components remain reserved. Limit two per order.

## Per-order economics

- Net collected merchandise revenue: INR 1,149
- Product COGS: INR 430
- Packaging: INR 35
- Payment fee: INR 26
- Outbound shipping: INR 82
- Variable fulfillment: INR 24
- Expected return cost: 0.06 x INR 180 = INR 10.80
- Expected RTO loss: 0.08 x INR 210 = INR 16.80

Variable cost before acquisition = 430 + 35 + 26 + 82 + 24 + 10.80 + 16.80 = INR 624.60.

CM1 = 1,149 - 624.60 = INR 524.40.

At illustrative variable acquisition cost of INR 310:

CM2 = 524.40 - 310 = INR 214.40.

The original cost inputs, not these example numbers, must be used in production.

## Downside

If RTO probability rises to 0.15 and return probability to 0.10:

Expected return cost = 0.10 x 180 = INR 18.  
Expected RTO loss = 0.15 x 210 = INR 31.50.

Revised CM1 = 1,149 - (430 + 35 + 26 + 82 + 24 + 18 + 31.50) = INR 502.50.

The candidate still clears an illustrative INR 480 CM1 floor, but only by INR 22.50. The stop rule therefore includes a delivered-order and RTO guardrail.

## Test card

Hypothesis: presenting the compatible pair as one guided routine increases CM2 per eligible first-time PDP session without increasing return, RTO, or support-contact rate.

Control: individual products.  
Treatment: Starter Pair module.  
Primary metric: CM2 per eligible session.  
Guardrails: CM1 per delivered order, RTO, return, cancellation, out-of-stock exposure, and support-contact rate.  
Stop: pause if inventory coverage falls below the approved reservation or any truth or checkout defect appears.  
Rollback: remove module and automatic bundle rule, preserve order reporting, and honor placed orders.

Decision: recommend a bounded test after finance verifies the tax and payment-fee basis and operations reserves both components.
