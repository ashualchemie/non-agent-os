# Operator procedure: Winning Offers/Bundles Generator Agent

Trigger: the operator starts a task with a completed intake.

1. Lock currency, taxes, quantities and eligible order state.
2. Calculate contribution before acquisition for each candidate offer.
3. Compare bundle, quantity break, free shipping and gift scenarios.
4. Reject candidates below margin or stock constraints and record assumptions.
5. Write approved offer rules, exclusions, claim wording and operational handoffs.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
