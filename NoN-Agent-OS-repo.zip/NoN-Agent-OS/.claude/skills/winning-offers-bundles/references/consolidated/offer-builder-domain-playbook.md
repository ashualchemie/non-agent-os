# Offer Builder Domain Playbook

## Economic model

Use one currency and one tax basis throughout.

Gross item revenue = sum(quantity x selling price before order discount).

Net merchandise revenue = gross item revenue - item discounts - order discounts - expected refunds allocated to merchandise.

Net collected revenue = net merchandise revenue + shipping charged - tax collected when tax is excluded from revenue.

Variable cost = product COGS + packaging + payment fees + outbound shipping + variable fulfillment + expected return cost + expected RTO loss + gift cost.

CM1 = net collected revenue - variable cost.

CM2 = CM1 - variable acquisition cost.

CM1 rate = CM1 / net collected revenue.

Break-even variable acquisition cost per delivered order = CM1 before acquisition.

If a cost is unknown, preserve it as an unresolved input. Never treat it as zero.

## Expected loss

Expected return cost = return probability x average cost per return.

Expected RTO loss = RTO probability x average loss per RTO.

Use cohort-specific rates when prepaid, COD, geography, product, or channel materially differ.

## Offer architecture

Every offer must define:

- target situation and customer job
- offer unit and included SKUs or variants
- visible price and verified reference basis
- value beyond discount
- eligibility, exclusions, stacking, and limit
- start, end, timezone, owner, and approval
- inventory reservation and substitution rule
- customer-service explanation
- channels and destination consistency
- test hypothesis, metric, guardrails, stop rule, and rollback

## Bundle logic

Accept a bundle only when products solve one coherent use case, are compatible, and have viable inventory and contribution. Calculate economics at bundle level. Avoid forcing slow stock into an unrelated bundle.

Bundle attach rate = bundle orders / eligible orders.

Incremental CM2 per eligible session = test CM2 per eligible session - control CM2 per eligible session.

## Shipping threshold

Use a threshold model rather than a copied competitor number.

Candidate threshold contribution = candidate order revenue x contribution rate before shipping subsidy - shipping cost - incremental handling.

Assess the distribution of current order values, likely basket-building behavior, product compatibility, and customer clarity. A threshold must not create a cliff that encourages returns or irrelevant additions.

## Scenario table

Build at least:

- baseline without new offer
- expected offer case
- weak uplift case
- higher return or RTO case
- inventory-constrained case

Show assumptions separately from results.

## Test design

State the primary hypothesis, eligible population, control, treatment, primary metric, margin and service guardrails, minimum run condition, stop rule, and decision rule. Do not declare a win from revenue alone if contribution, returns, or customer harm worsens.
