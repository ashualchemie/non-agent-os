# Offer Builder Decision Rules

## Discount

Approve for testing only if:

- the customer job and behavior change are explicit
- CM1 remains above the approved floor in the downside scenario
- price and reference price are truthful
- terms appear before commitment
- the promotion does not conflict with current customers or channel agreements

## Bundle

Reject or redesign when any component is incompatible, materially stock constrained, hard to fulfill, likely to be returned independently without a policy, or unrelated to the use case.

## Free shipping

Require pincode or zone cost basis, current order-value distribution, threshold scenario, and a plan for split shipments. Do not assume one national shipping cost.

## Gift with purchase

Treat the gift as inventory and cost. Define eligible order state, substitution, exhaustion behavior, refund treatment, and customer communication. Never display a gift after inventory is exhausted.

## Quantity break

Require a plausible consumption or gifting need. Make the unit math clear. Avoid over-purchase pressure for perishable, regulated, or low-repeat products.

## Subscription

Require expected consumption interval, easy cancellation, consent, billing transparency, failure handling, inventory reliability, and a contribution scenario. Do not preselect consent.

## Urgency and scarcity

Use only verifiable time, inventory, capacity, or eligibility limits. Never manufacture countdown resets, fake remaining quantities, or generic "today only" claims.

## Stacking

Create a matrix for codes, automatic discounts, loyalty, referral, employee, marketplace, shipping, gift, and subscription benefits. Unspecified combinations are blocked, not assumed.

## Decision outcomes

- Recommend test: evidence and downside gates pass.
- Recommend revision: customer value exists but one or more rules need repair.
- Blocked: required cost, inventory, policy, or approval input is missing.
- Reject: downside violates approved margin, truth, service, or inventory guardrail.
