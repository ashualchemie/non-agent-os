# Winning Offers/Bundles Generator Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/offer-builder-decision-rules.md`: offer builder procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/offer-builder-domain-playbook.md`: offer builder procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/offer-builder-advanced-search-controls.csv`: offer builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/offer-builder-d2c-controls.csv`: offer builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/offer-builder-d2c-prompts.csv`: offer builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/offer-builder-d2c-workflows.csv`: offer builder controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/stock-planning-decision-rules.md`: stock planning procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/stock-planning-domain-playbook.md`: stock planning procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-advanced-search-controls.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-d2c-controls.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-d2c-prompts.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/stock-planning-d2c-workflows.csv`: stock planning controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
