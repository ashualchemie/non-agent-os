# Winning Offers/Bundles Generator Agent: domain playbook

## Decision contract

Design offer and bundle scenarios that fit contribution margins, stock and customer motivations. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Lock currency, taxes, quantities and eligible order state.

Required working record: Offer scenario table. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Calculate contribution before acquisition for each candidate offer.

Required working record: Contribution worksheet. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Compare bundle, quantity break, free shipping and gift scenarios.

Required working record: Selected offer and rationale. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Reject candidates below margin or stock constraints and record assumptions.

Required working record: Stacking and eligibility rules. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Write approved offer rules, exclusions, claim wording and operational handoffs.

Required working record: Implementation and stock checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
