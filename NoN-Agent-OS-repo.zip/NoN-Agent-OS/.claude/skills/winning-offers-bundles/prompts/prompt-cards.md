# Winning Offers/Bundles Generator Agent: prompt cards

## Offer scenario table

Using my completed intake and supplied evidence, prepare the offer scenario table for this task. Follow the Winning Offers/Bundles Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Contribution worksheet

Using my completed intake and supplied evidence, prepare the contribution worksheet for this task. Follow the Winning Offers/Bundles Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Selected offer and rationale

Using my completed intake and supplied evidence, prepare the selected offer and rationale for this task. Follow the Winning Offers/Bundles Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
