# Illustrative worked packet: Creator & Affiliate Growth Agent

All example records, entities and timings below are illustrative. They explain the procedure and are not customer results or executed workflows.

## Supplied candidate evidence

Illustrative candidate C-01 has an operator-supplied profile URL, dated product-demo examples and the correct target language. C-02 has relevant content but no verified contact or market evidence. No rates, audience demographics or past sales are supplied.

## Qualification register

| Candidate | Fit | Missing | Next action |
|---|---|---|---|
| C-01 | Content demonstrates the product category in the target language. | Audience geography, rate and paid usage terms. | Draft a question-led outreach message. |
| C-02 | Category content appears relevant. | Contact, geography and current activity. | Request evidence before commercial qualification. |

## Outreach draft

"Hi [verified name], I liked the way your [linked example] explains the product in use. We are preparing a campaign for [verified product] and would like to discuss a short demonstration. Could you share your availability, audience markets, rate and paid usage terms?" No message is sent from this file.

## Deliverable and rights brief

Draft one 9:16 product demonstration, a clear opening, actual use footage and a CTA. Ask for usage channels, territory, term, editing permission, exclusivity and renewal in writing. Do not mark rights approved until an actual agreement exists.

## Affiliate economics

Use net eligible revenue after refunds. Contribution after commission = net revenue minus product, fulfilment, payment, shipping, return, commission and seeding costs. Missing amounts remain blank. No forecast sales are invented.

## Handoff

UGC Video prepares the production brief. Winning Offers/Bundles approves commercial economics. The Operator owns authorized outreach, agreements and dispatch.
