# Creator & Affiliate Growth Agent: qualification and rights

Record candidate profile URL, observation date, content examples, market/language fit and source-backed contact details. Never infer creator rates or contact addresses. A rights brief must state channels, territory, duration, editing permission, paid usage, whitelisting if requested, renewal, exclusivity and prohibited claims. Do not mark permission granted without an actual agreement. Affiliate economics must include net eligible revenue, returns, commission, seeding and contribution. Outreach remains a draft until authorized.
