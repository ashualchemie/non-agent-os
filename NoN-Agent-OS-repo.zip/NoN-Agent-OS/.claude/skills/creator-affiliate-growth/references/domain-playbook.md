# Creator & Affiliate Growth Agent: domain playbook

## Decision contract

Qualify creator and affiliate candidates and prepare briefs, outreach drafts and economics worksheets. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Create an evidence register for audience fit, content quality and brand suitability.

Required working record: Candidate qualification register. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Score candidates on supplied evidence and flag missing commercial/contact details.

Required working record: Outreach drafts. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Calculate seeding and commission scenarios with refund and attribution assumptions.

Required working record: Creator production brief. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Prepare individualized outreach drafts, briefs and deliverable/rights checklists.

Required working record: Rights and deliverables checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Organize response, agreement, dispatch, content and affiliate measurement handoffs.

Required working record: Affiliate economics worksheet. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
