# Output: Creator & Affiliate Growth Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Candidate qualification register

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Outreach drafts

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Creator production brief

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Rights and deliverables checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Affiliate economics worksheet

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
