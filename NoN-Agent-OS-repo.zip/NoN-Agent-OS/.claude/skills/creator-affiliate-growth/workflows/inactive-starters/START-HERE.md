# Candidate scoring starter

An optional inactive input/scoring packet. No creator database, outreach sender or live contact collection is configured. Supply verified candidate records and review the output before use.
