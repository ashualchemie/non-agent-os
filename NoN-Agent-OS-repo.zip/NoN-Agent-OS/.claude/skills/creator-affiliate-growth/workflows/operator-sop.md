# Operator procedure: Creator & Affiliate Growth Agent

Trigger: the operator starts a task with a completed intake.

1. Create an evidence register for audience fit, content quality and brand suitability.
2. Score candidates on supplied evidence and flag missing commercial/contact details.
3. Calculate seeding and commission scenarios with refund and attribution assumptions.
4. Prepare individualized outreach drafts, briefs and deliverable/rights checklists.
5. Organize response, agreement, dispatch, content and affiliate measurement handoffs.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
