# Creator & Affiliate Growth Agent: prompt cards

## Candidate qualification register

Using my completed intake and supplied evidence, prepare the candidate qualification register for this task. Follow the Creator & Affiliate Growth Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Outreach drafts

Using my completed intake and supplied evidence, prepare the outreach drafts for this task. Follow the Creator & Affiliate Growth Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Creator production brief

Using my completed intake and supplied evidence, prepare the creator production brief for this task. Follow the Creator & Affiliate Growth Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
