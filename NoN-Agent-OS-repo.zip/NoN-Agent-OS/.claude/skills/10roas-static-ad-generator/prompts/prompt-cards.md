# 10ROAS Static Ad Generator Agent: prompt cards

## Static ad copy pack

Using my completed intake and supplied evidence, prepare the static ad copy pack for this task. Follow the 10ROAS Static Ad Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Composition brief

Using my completed intake and supplied evidence, prepare the composition brief for this task. Follow the 10ROAS Static Ad Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.

## Image-generation prompt

Using my completed intake and supplied evidence, prepare the image-generation prompt for this task. Follow the 10ROAS Static Ad Generator Agent contract. Show evidence IDs beside factual observations, label assumptions, and return missing inputs instead of inventing them. Keep output within this role and finish with an actionable handoff.
