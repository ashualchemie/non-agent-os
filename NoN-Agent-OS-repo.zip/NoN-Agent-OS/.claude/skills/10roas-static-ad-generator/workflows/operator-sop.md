# Operator procedure: 10ROAS Static Ad Generator Agent

Trigger: the operator starts a task with a completed intake.

1. Lock concept, audience, product variant, offer and destination.
2. Write hook, primary text, headline and CTA using supported product facts.
3. Specify one visual hierarchy, focal product, contrast, spacing and safe areas.
4. Create an image-generation prompt with exact asset references and forbidden changes.
5. Provide export names, dimensions, copy map and a human review checklist.

Before handoff, check `review/scorecard.csv` manually. This release consolidates task files; it does not run agent behavior tests. Record any missing input and route the draft using the handoff template. If an action fails, report what actually happened and do not repeat a money or messaging action without checking state.
