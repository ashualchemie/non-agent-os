# Illustrative worked packet: 10ROAS Static Ad Generator Agent

All example records, entities and timings below are illustrative. They explain the procedure and are not customer results or executed workflows.

## Supplied sample brief

Illustrative product: a slim card wallet. Product facts PF-01: six-card capacity. PF-02: 8 mm depth when empty. Asset AS-01: the buyer's approved front-view product photograph. Offer OF-01: the operator's current verified price and destination. No ROAS, customer testimonial or durability outcome is supplied.

## Static concept

Customer tension: bulky pockets. Hook: "Six cards. One slimmer carry." Headline: "Make room in your pocket." CTA: "See the slim wallet." Use the supplied price only after OF-01 is verified.

## Composition

1080 x 1350 portrait. One large wallet hero in the lower-middle area. Hook in the top quarter. A small fact chip reads "Six-card capacity" beside the product. Keep logo and CTA in a clear bottom band. Do not add a review rating, discount, additional product or unsupported measurement.

## Image-generation handoff

Use AS-01 as the product identity reference. Preserve the color, shape and visible details. Create a clean studio setting using the brand's approved palette. Place the product at a three-quarter angle with soft contact shadow. Leave the upper quarter clear for exact copy applied by the designer. Do not generate fake certification, customer proof or performance claims.

## Export and decision

Filename: WALLET-C01-STATIC-PORTRAIT-V01. Deliver image, exact copy mapping, source asset ID and claim register. Performance Marketing owns the proposed learning decision. 10ROAS is the agent's name, not a promise in this ad. The paid template collection has not been included.
