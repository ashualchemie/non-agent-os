# 10ROAS Static Ad Generator Agent: supporting module index

These procedural references and controls are consolidated from the existing base library. They are instruction material, not API integrations, proof of execution or paid add-on collections. Older module headings describe supporting disciplines; the current role boundary controls the task.

- `references/consolidated/ad-creative-decision-rules.md`: ad creative procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/consolidated/ad-creative-domain-playbook.md`: ad creative procedural reference. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/ad-creative-advanced-search-controls.csv`: ad creative controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/ad-creative-d2c-controls.csv`: ad creative controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/ad-creative-d2c-prompts.csv`: ad creative controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
- `references/controls/ad-creative-d2c-workflows.csv`: ad creative controls and task examples. Use only the portions relevant to this agent; the current role contract takes precedence.
