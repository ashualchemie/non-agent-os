# Ad Creative Domain Playbook

## Evidence stack

Build concepts from:

- exact customer language with source and permission
- observed trigger, desired progress, barrier, and alternative
- approved product mechanism and demonstrations
- claim ledger and proof records
- current offer and destination truth
- historical concept-level performance
- production rights and constraints

Separate public evidence, internal-only evidence, and approved ad claims.

## Creative taxonomy

Record these fields independently:

- concept: the customer tension and central belief
- angle: the perspective used to frame the tension
- execution: founder answer, customer point of view, demonstration, comparison, static, carousel, or another production approach
- hook: opening visual and first line
- proof: demonstration, specification, review, process, expert, or operational fact
- format: placement and aspect ratio
- creator or talent
- offer and destination

A new hook or crop is not automatically a new concept.

## Concept card

Every concept contains:

- source-linked customer situation
- awareness level
- current belief and desired belief
- tension
- product role and mechanism
- verified proof
- objection handled
- first-frame visual
- first line
- middle beats
- CTA and destination
- exclusions and claim notes
- formats and production requirements
- hypothesis and disconfirming signal

## Production brief

Specify duration, aspect ratios, safe zones, shot list, props, location, product use, creator direction, on-screen text, captions, audio, edit rhythm, disclosure, pack or price state, and fallback asset. For statics, specify hierarchy, crop, scale, typography, alt text, and text-only fallback.

## Test design

Test one primary variable at a time where feasible. A useful matrix separates concept, execution, hook, creator, format, audience, and offer. Define minimum run conditions from the account economics and signal volume, not a universal threshold.

Primary outcome should connect to the business decision. Supporting signals can include spend, reach, frequency, hook or thumb-stop proxy, click-through, landing-page view rate, purchase rate, delivered CAC, CM2, and new-customer share.

## Learning record

Record what ran, where, when, spend, audience, placement, destination, offer, tracking health, stock state, concurrent changes, outcomes, uncertainty, decision, and next test. Preserve losing concepts because they define what was learned.
