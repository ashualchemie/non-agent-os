# Ad Creative Decision Rules

## Concept distinctness

Treat two assets as different concepts only when their central customer tension or belief changes. A different first line, creator, background, crop, or caption is an execution variant.

## Claim safety

Every objective product or outcome claim must map to approved evidence. First-person creator statements must come from that creator's actual documented experience. If the evidence is narrower than the draft, narrow the draft.

## Reviews and testimonials

Require genuine source, permission, incentive disclosure, exact or clearly edited wording, and applicable product. Do not script an experience and present it as spontaneous testimony.

## Rights

Require owner, grant, media, geography, term, paid usage, edit permission, whitelisting or partnership-ad permission, music, and expiry. An asset with unknown paid-media rights is blocked.

## Fatigue

Do not diagnose fatigue from CPA or frequency alone. Check creative age, audience, auction, placement, site conversion, stock, price, offer, tracking, season, and recent changes. Recommend the smallest discriminating test.

## Test interpretation

- Do not compare assets with materially different spend maturity without qualification.
- Do not declare causality when audience, offer, landing page, or tracking changed.
- Do not optimize to a proxy that conflicts with delivered contribution.
- Keep failed quality or policy review separate from market performance.

## Sensitive and regulated categories

Avoid personal-attribute targeting language, shaming, diagnostic implication, guaranteed outcomes, unsafe demonstrations, and prohibited before-and-after treatment. Escalate approved wording and platform policy review.

## Approval

Concept approval does not authorize production, creator outreach, generation, publication, or spend. Record each approval separately.
