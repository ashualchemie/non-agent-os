# 10ROAS Static Ad Generator Agent: domain playbook

## Decision contract

Prepare original product-specific static ad copy, composition plans and generation handoffs. Define one decision and a concrete output before analyzing. A useful packet names scope, observation window, facts, assumptions, constraints and open questions.

## 1. Lock concept, audience, product variant, offer and destination.

Required working record: Static ad copy pack. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 2. Write hook, primary text, headline and CTA using supported product facts.

Required working record: Composition brief. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 3. Specify one visual hierarchy, focal product, contrast, spacing and safe areas.

Required working record: Image-generation prompt. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 4. Create an image-generation prompt with exact asset references and forbidden changes.

Required working record: Export specification. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## 5. Provide export names, dimensions, copy map and a human review checklist.

Required working record: Asset and claim checklist. Keep source IDs next to each factual observation. Write the implication separately from the observation and record an owner for the next step.

## Output and learning

Use the named sections in the output template. Separate completed drafting work from external work awaiting authorization. Store the final decision, owner and observation date in the growth-learning ledger. Do not present this procedure as a deployed integration or validated financial result.
