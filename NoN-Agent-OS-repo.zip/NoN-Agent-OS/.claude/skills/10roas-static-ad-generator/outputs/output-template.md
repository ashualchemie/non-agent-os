# Output: 10ROAS Static Ad Generator Agent

Status: draft / requires_input / ready_for_review
Task: 
Scope and window: 
Market/currency: 

## Static ad copy pack

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Composition brief

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Image-generation prompt

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Export specification

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Asset and claim checklist

Finding/draft: 
Evidence IDs: 
Assumptions or limitation: 
Owner/next decision: 

## Open questions and action state

Missing fields: 
Actions completed: 
Actions proposed: 
Authorization needed: 
